#!/usr/bin/env python3
"""
CRT - a tiny scripting language that compiles to CVM bytecode.

CRT (the language) compiles down to CVM ("Compact Virtual Machine")
bytecode: a simple stack machine with a binary instruction format you can
disassemble and inspect. This file contains the whole toolchain:

    1. Opcodes & ISA
    2. Lexer & Parser   (source text -> tokens -> AST)
    3. Compiler         (AST -> CVM bytecode)
    4. CVM Runtime      (bytecode -> execution)
    5. CLI / REPL / Disassembler

Language features: variables, numbers/strings/bools/null, lists, objects,
classes with instance methods, imports of compiled classes, if/else
if/else, while, for, break/continue, functions with return values, and a
handful of built-ins (len, str, int, float, type, plus a math library:
sin/cos/tan, sinh/cosh/tanh, sqrt, log, pi/e, etc. -- see BUILTINS).
Graphics mode adds 2D/3D vertices, filled (and textured) polygons, and a
3D camera object -- see GFX_BUILTINS and NATIVE_METHODS.

CLI usage:
    crt run file.ct                  Run a .ct source file directly
    crt build file.ct -o file.cvm    Compile to a .cvm bytecode file
    crt exec file.cvm                Execute a compiled .cvm file
    crt disasm file.cvm              Disassemble a compiled .cvm file
    crt asm file.asm -o file.cvm     Assemble CRT assembly to bytecode
    crt                               Start an interactive REPL
"""

import sys
import os
import struct
import re
import json
import argparse
import math
import importlib
import random as _random

# =====================================================================
# 1. OPCODES & ISA DEFINITION
# =====================================================================
#
# Each instruction is a fixed 8-byte record:
#   opcode   : u8   - which operation (see OPCODES)
#   arg_type : u8   - how to interpret arg_val (0=none, 1=immediate, 2=string index)
#   arg_val  : i32  - big-endian signed 32-bit immediate / string-table index / jump target
#   extra    : i16  - secondary small operand (currently only used by CALL for argc)

OPCODES = {
    "HALT":          0x00,
    "PUSH_INT":      0x01,
    "PUSH_STR":      0x02,
    "PUSH_BOOL":     0x03,
    "LOAD":          0x04,
    "STORE":         0x05,
    "ADD":           0x06,
    "SUB":           0x07,
    "MUL":           0x08,
    "DIV":           0x09,
    "EQ":            0x0A,
    "NEQ":           0x0B,
    "LT":            0x0C,
    "GT":            0x0D,
    "LTE":           0x0E,
    "GTE":           0x0F,
    "PRINT":         0x10,
    "JUMP":          0x11,
    "JUMP_IF_FALSE": 0x12,
    "MAKE_LIST":     0x13,
    "MAKE_OBJECT":   0x14,
    "GET_MEMBER":    0x15,
    "SET_MEMBER":    0x16,
    "GET_INDEX":     0x17,
    "SET_INDEX":     0x18,
    "MOD":           0x19,
    "NEG":           0x1A,
    "NOT":           0x1B,
    "PUSH_FLOAT":    0x1C,
    "PUSH_NULL":     0x1D,
    "POP":           0x1E,
    "DUP":           0x1F,
    "JUMP_IF_TRUE":  0x20,
    "CALL":          0x21,
    "CALL_BUILTIN":  0x22,
    "RET":           0x23,
    "MAKE_FRAME":    0x24,   # enter a new local scope, binding params (arg_val = number of params)
    "STORE_LOCAL":   0x25,   # always bind in the current scope (used for 'let' decls and params)
    "CALL_GFX":      0x26,   # call a pygame graphics builtin (arg_val = string index of name, extra = argc)
    "CALL_METHOD":   0x27,   # dynamic method dispatch: pops receiver object off the
                             # stack (pushed *before* the args), reads its __class__,
                             # looks up "<class>.<method>" in the function table, and
                             # calls it with the receiver prepended as `self`.
                             # arg_val = string index of method name, extra = argc
                             # (not counting self/the receiver)
    "PY_IMPORT":     0x28,   # imports a real Python module by dotted name
                             # (arg_val = string index of the dotted module
                             # path, e.g. "os.path"). Doesn't push anything --
                             # the module is stashed in the VM's own registry,
                             # not on the CRT value stack, since a Python
                             # module isn't a CRT value. See run() for how
                             # scripts call into it.
}

REV_OPCODES = {v: k for k, v in OPCODES.items()}

ARG_NONE, ARG_IMM, ARG_STR = 0, 1, 2

BUILTINS = (
    "len", "str", "int", "float", "type", "upper", "lower",
    # JSON
    "json_encode", "json_decode",
    # File I/O
    "file_read", "file_write", "file_append", "file_exists", "file_delete",
    # Math: constants (called as zero-arg functions, e.g. `pi()`)
    "pi", "e", "tau",
    # Math: trig
    "sin", "cos", "tan", "asin", "acos", "atan", "atan2",
    # Math: hyperbolic
    "sinh", "cosh", "tanh", "asinh", "acosh", "atanh",
    # Math: powers, roots, logs
    "sqrt", "pow", "exp", "log", "log2", "log10",
    # Math: rounding & misc
    "floor", "ceil", "round", "abs", "deg", "rad",
    # Vectors & matrices
    "vec2", "vec3", "vec4", "vec_dot", "vec_cross", "vec_length",
    "vec_normalize", "vec_lerp",
    "mat4_identity", "mat4_translation", "mat4_scale",
    "mat4_rotate_x", "mat4_rotate_y", "mat4_rotate_z",
    # Transforms
    "transform", "transform_matrix", "transform_forward",
    # Collision helpers
    "aabb", "sphere", "aabb_intersects", "sphere_intersects",
    "aabb_contains_point", "aabb_sphere_intersects", "ray_aabb_intersects",
    # Python interop (see py_import)
    "run",
    # Math: min/max/clamp/random
    "min", "max", "clamp", "random", "random_range", "randint",
    # Strings
    "split", "join", "trim", "replace", "contains", "index_of",
    # Lists
    "push", "pop", "sort", "reverse", "slice",
)

# Single-argument math builtins that map directly onto a function from the
# `math` module. Kept as a table (rather than one elif per name) since
# they all share the same "pop one number, call, push a float" shape;
# atan2/pow/log take extra arguments and are handled separately.
_MATH_UNARY = {
    "sin": math.sin, "cos": math.cos, "tan": math.tan,
    "asin": math.asin, "acos": math.acos, "atan": math.atan,
    "sinh": math.sinh, "cosh": math.cosh, "tanh": math.tanh,
    "asinh": math.asinh, "acosh": math.acosh, "atanh": math.atanh,
    "sqrt": math.sqrt, "exp": math.exp, "log2": math.log2, "log10": math.log10,
}

# ---------------------------------------------------------------------
# Vector/matrix math
#
# Vectors and matrices are plain CRT objects (dicts) tagged with a
# reserved key, same trick as pygame_vertex2/3 and the native camera --
# no new runtime value type needed. Tags:
#   {"__vec__": 2|3|4, "x":.., "y":.., ["z":..], ["w":..]}
#   {"__mat__": 4, "m": [16 floats, row-major]}
#
# Operator overloading (+, -, *, unary -) is handled in CVM._arith/_neg
# by checking for these tags before falling through to plain number
# arithmetic -- see vec_add/vec_sub/vec_scale/mat_mul_vec/mat_mul_mat
# below, which those opcodes call into.
# ---------------------------------------------------------------------

def make_vec(*components):
    n = len(components)
    keys = ("x", "y", "z", "w")[:n]
    d = {"__vec__": n}
    for k, v in zip(keys, components):
        d[k] = float(v)
    return d


def vec_components(v, n):
    keys = ("x", "y", "z", "w")[:n]
    return tuple(v[k] for k in keys)


def vec_add(a, b):
    n = a["__vec__"]
    if b.get("__vec__") != n:
        raise TypeError("vector dimension mismatch")
    return make_vec(*(x + y for x, y in zip(vec_components(a, n), vec_components(b, n))))


def vec_sub(a, b):
    n = a["__vec__"]
    if b.get("__vec__") != n:
        raise TypeError("vector dimension mismatch")
    return make_vec(*(x - y for x, y in zip(vec_components(a, n), vec_components(b, n))))


def vec_scale(v, s):
    n = v["__vec__"]
    return make_vec(*(x * s for x in vec_components(v, n)))


def vec_neg(v):
    n = v["__vec__"]
    return make_vec(*(-x for x in vec_components(v, n)))


def vec_dot(a, b):
    n = a["__vec__"]
    if b.get("__vec__") != n:
        raise TypeError("vector dimension mismatch")
    return sum(x * y for x, y in zip(vec_components(a, n), vec_components(b, n)))


def vec_length(v):
    n = v["__vec__"]
    return math.sqrt(sum(x * x for x in vec_components(v, n)))


def vec_normalize(v):
    length = vec_length(v)
    if length < 1e-9:
        raise ValueError("cannot normalize a zero-length vector")
    return vec_scale(v, 1.0 / length)


def vec3_cross(a, b):
    return make_vec(
        a["y"] * b["z"] - a["z"] * b["y"],
        a["z"] * b["x"] - a["x"] * b["z"],
        a["x"] * b["y"] - a["y"] * b["x"],
    )


def vec_lerp(a, b, t):
    n = a["__vec__"]
    return make_vec(*(x + (y - x) * t for x, y in zip(vec_components(a, n), vec_components(b, n))))


def make_mat4(values):
    """values: 16 floats, row-major (values[0:4] is row 0, etc.)."""
    return {"__mat__": 4, "m": [float(v) for v in values]}


def mat4_identity():
    return make_mat4([1, 0, 0, 0,
                       0, 1, 0, 0,
                       0, 0, 1, 0,
                       0, 0, 0, 1])


def mat4_translation(x, y, z):
    return make_mat4([1, 0, 0, x,
                       0, 1, 0, y,
                       0, 0, 1, z,
                       0, 0, 0, 1])


def mat4_scale(x, y, z):
    return make_mat4([x, 0, 0, 0,
                       0, y, 0, 0,
                       0, 0, z, 0,
                       0, 0, 0, 1])


def mat4_rotation_x(deg):
    r = math.radians(deg)
    c, s = math.cos(r), math.sin(r)
    return make_mat4([1, 0, 0, 0,
                       0, c, -s, 0,
                       0, s, c, 0,
                       0, 0, 0, 1])


def mat4_rotation_y(deg):
    r = math.radians(deg)
    c, s = math.cos(r), math.sin(r)
    return make_mat4([c, 0, s, 0,
                       0, 1, 0, 0,
                       -s, 0, c, 0,
                       0, 0, 0, 1])


def mat4_rotation_z(deg):
    r = math.radians(deg)
    c, s = math.cos(r), math.sin(r)
    return make_mat4([c, -s, 0, 0,
                       s, c, 0, 0,
                       0, 0, 1, 0,
                       0, 0, 0, 1])


def mat4_mul(a, b):
    """4x4 * 4x4 -> 4x4, both row-major flat lists of 16."""
    am, bm = a["m"], b["m"]
    out = [0.0] * 16
    for row in range(4):
        for col in range(4):
            s = 0.0
            for k in range(4):
                s += am[row * 4 + k] * bm[k * 4 + col]
            out[row * 4 + col] = s
    return make_mat4(out)


def mat4_mul_vec(m, v):
    """4x4 * a vec3 or vec4. A vec3 is treated as a point (w=1 implied)
    and the result is a vec3 again (w is dropped after use, matching how
    the rest of this codebase treats 3D points -- no explicit clip-space
    homogeneous divide is needed here since that's the camera's job)."""
    mm = m["m"]
    n = v["__vec__"]
    x, y, z = v["x"], v["y"], v["z"]
    w = v["w"] if n == 4 else 1.0
    rx = mm[0] * x + mm[1] * y + mm[2] * z + mm[3] * w
    ry = mm[4] * x + mm[5] * y + mm[6] * z + mm[7] * w
    rz = mm[8] * x + mm[9] * y + mm[10] * z + mm[11] * w
    if n == 4:
        rw = mm[12] * x + mm[13] * y + mm[14] * z + mm[15] * w
        return make_vec(rx, ry, rz, rw)
    return make_vec(rx, ry, rz)


# Graphics builtins ("pygame mode"). Each maps to the argument count(s) it
# accepts -- an int for a fixed arity, or a tuple for a few allowed arities
# (pygame_clear can take 0 args, clearing to black, or 3 for an explicit
# color) -- so the compiler can catch wrong-arity calls the same way it
# does for ordinary functions. These compile to CALL_GFX instead of
# CALL_BUILTIN so the runtime only has to import pygame when a script
# actually uses one.
GFX_BUILTINS = {
    "pygame_init":        3,       # (width, height, title) -> null
    "pygame_quit":        0,       # () -> null
    "pygame_clear":       (0, 3),  # () clears to black, or (r, g, b) -> null
    "pygame_rect":        7,       # (x, y, w, h, r, g, b) -> null
    "pygame_circle":      6,       # (x, y, radius, r, g, b) -> null
    "pygame_line":        7,       # (x1, y1, x2, y2, r, g, b) -> null
    "pygame_text":        6,       # (x, y, text, r, g, b) -> null
    "pygame_flip":        0,       # () -> null
    "pygame_poll_quit":   0,       # () -> bool (true if window close was requested)
    "pygame_key":         1,       # (name) -> bool
    "pygame_tick":        1,       # (fps) -> float (ms elapsed since last tick)
    # Textures (loaded via Pillow, converted to a pygame surface)
    "pygame_load_image":  1,       # (path) -> int image handle
    "pygame_draw_image":  3,       # (handle, x, y) -> null
    "pygame_image_size":  1,       # (handle) -> {w: ..., h: ...}
    # Audio
    "pygame_load_sound":  1,       # (path) -> int sound handle
    "pygame_play_sound":  1,       # (handle) -> null
    "pygame_stop_sound":  1,       # (handle) -> null
    "pygame_set_volume":  2,       # (handle, volume 0.0-1.0) -> null
    # Mouse
    "pygame_mouse_x":       0,     # () -> int, current mouse x position
    "pygame_mouse_y":       0,     # () -> int, current mouse y position
    "pygame_mouse_clicked": 0,     # () -> bool, true once on the frame the
                                    # left button was pressed down (edge-
                                    # triggered, like pygame_poll_quit)
    # 2D/3D vertices and polygons
    "pygame_vertex2":        2,    # (x, y) -> a 2D vertex object
    "pygame_vertex3":        3,    # (x, y, z) -> a 3D vertex object
    "pygame_polygon":        (1, 4),  # (vertices) filled white, or
                                       # (vertices, r, g, b) for a flat
                                       # color -> null. Vertices can be
                                       # all 2D or all 3D (3D ones are
                                       # projected through the active
                                       # pygame_camera).
    "pygame_polygon_texture": 3,   # (vertices, image_handle, uvs) -> null
                                    # textured 2D/3D filled polygon; uvs is
                                    # a list of {u, v} in 0..1, one per
                                    # vertex, matching pygame_image_size
    # 3D camera
    "pygame_camera":         0,    # () -> a camera object (a.pos(x,y,z),
                                    # a.rotate(yaw, pitch), a.fov(degrees)
                                    # are called as methods on it)

    # Simple clickable/positionable on-screen objects
    "pygame_object":         0,    # () -> an object (o.rectangle(...),
                                    # o.pos(...), o.clicked(), o.draw()
                                    # are called as methods on it)
}

# Methods callable on native objects returned by graphics builtins (e.g.
# pygame_camera()). These are dicts tagged with a reserved "__native__"
# key rather than "__class__", so CALL_METHOD (see the opcode's runtime
# handler) routes them to _call_native_method() below instead of the
# user-defined function table. Arity is checked there, the same way
# CALL_METHOD already checks arity for real class instances. A value can
# be a single int (fixed arity) or a tuple of allowed arities, same
# convention as GFX_BUILTINS.
NATIVE_METHODS = {
    "camera": {
        "pos":     3,   # a.pos(x, y, z) -> null, sets the camera's position
        "rotate":  2,   # a.rotate(yaw, pitch) -> null, angles in degrees
        "fov":     1,   # a.fov(degrees) -> null, sets the field of view
        "look_at": 1,   # a.look_at(target_vec3) -> null, points the camera
                         # at a world position (sets yaw/pitch to match)
        "orbit":   2,   # a.orbit(target_vec3, distance) -> null, moves the
                         # camera to `distance` away from target along its
                         # current look direction, still looking at target
                         # (handy for "orbit the camera around this angle"
                         # loops: rotate() then orbit() each frame)
        "forward": 0,   # a.forward() -> vec3, the direction the camera is
                         # currently facing
        "position": 0,  # a.position() -> vec3, the camera's current position
    },
    "object": {
        "rectangle": 5,     # o.rectangle(w, h, r, g, b) -> null, gives the
                             # object a rectangle shape/size/color to draw
        "pos":       (0, 2, 3),  # o.pos() -> vec2/vec3, current position
                             # (whichever kind was last set; vec2(0,0) if
                             # never set). o.pos(x, y) sets a 2D screen
                             # position. o.pos(x, y, z) sets a 3D world
                             # position, projected each draw through the
                             # active pygame_camera, same as a
                             # pygame_vertex3-based polygon.
        "clicked":   0,     # o.clicked() -> bool, true once on the frame
                             # the object was clicked (edge-triggered)
        "draw":      0,     # o.draw() -> null, draws the object's current
                             # shape at its current position (call once
                             # per frame, before pygame_flip())
    },
}


class CRTError(Exception):
    """Base class for user-facing CRT errors with an optional source line."""
    def __init__(self, message, line=None):
        self.message = message
        self.line = line
        super().__init__(self.format())

    def format(self):
        if self.line is not None:
            return f"line {self.line}: {self.message}"
        return self.message


class LexError(CRTError):
    pass


class ParseError(CRTError):
    pass


class CompileError(CRTError):
    pass


class CRTRuntimeError(CRTError):
    pass


# =====================================================================
# 2. LEXER
# =====================================================================

TOKEN_TYPES = [
    ("COMMENT_BLOCK", r'/\*.*?\*/'),
    ("COMMENT_LINE",  r'//[^\n]*'),
    ("NEWLINE",  r'\n'),
    ("NUMBER",   r'\d+\.\d+|\d+'),
    ("STRING",   r'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\''),
    ("KEYWORD",  r'\b(let|if|else|while|for|fn|return|print|true|false|null|and|or|not|break|continue|class|import|from)\b'),
    ("IDENT",    r'[a-zA-Z_][a-zA-Z0-9_]*'),
    ("OP",       r'==|!=|<=|>=|&&|\|\||[+\-*/%=<>!]'),
    ("LPAREN",   r'\('),
    ("RPAREN",   r'\)'),
    ("LBRACE",   r'\{'),
    ("RBRACE",   r'\}'),
    ("LBRACK",   r'\['),
    ("RBRACK",   r'\]'),
    ("COLON",    r':'),
    ("COMMA",    r','),
    ("SEMI",     r';'),
    ("DOT",      r'\.'),
    ("SKIP",     r'[ \t\r]+'),
    ("MISMATCH", r'.'),
]

_TOKEN_RE = re.compile(
    '|'.join(f'(?P<{name}>{pattern})' for name, pattern in TOKEN_TYPES),
    re.DOTALL,
)

_ESCAPES = {'n': '\n', 't': '\t', 'r': '\r', '"': '"', "'": "'", '\\': '\\', '0': '\0'}


def _unescape(s):
    out = []
    i = 0
    while i < len(s):
        c = s[i]
        if c == '\\' and i + 1 < len(s):
            out.append(_ESCAPES.get(s[i + 1], s[i + 1]))
            i += 2
        else:
            out.append(c)
            i += 1
    return ''.join(out)


class Token:
    __slots__ = ("type", "value", "line")

    def __init__(self, type_, value, line):
        self.type = type_
        self.value = value
        self.line = line

    def __repr__(self):
        return f"Token({self.type}, {self.value!r}, line={self.line})"


def tokenize(code):
    tokens = []
    line = 1
    pos = 0
    length = len(code)
    while pos < length:
        m = _TOKEN_RE.match(code, pos)
        if not m:
            raise LexError(f"Unexpected character: {code[pos]!r}", line)
        kind = m.lastgroup
        value = m.group()
        pos = m.end()

        if kind == 'NEWLINE':
            line += 1
            continue
        elif kind in ('SKIP', 'COMMENT_LINE'):
            continue
        elif kind == 'COMMENT_BLOCK':
            line += value.count('\n')
            continue
        elif kind == 'MISMATCH':
            raise LexError(f"Unexpected character: {value!r}", line)
        elif kind == 'STRING':
            value = _unescape(value[1:-1])
        tokens.append(Token(kind, value, line))
    tokens.append(Token('EOF', None, line))
    return tokens


# =====================================================================
# AST NODES
# =====================================================================

class ASTNode:
    line = None


class ProgramNode(ASTNode):
    def __init__(self, stmts):
        self.stmts = stmts


class VarDeclNode(ASTNode):
    def __init__(self, name, val, line=None):
        self.name, self.val, self.line = name, val, line


class AssignNode(ASTNode):
    def __init__(self, target, val, line=None):
        self.target, self.val, self.line = target, val, line


class PrintNode(ASTNode):
    def __init__(self, expr, line=None):
        self.expr, self.line = expr, line


class IfNode(ASTNode):
    def __init__(self, branches, else_body, line=None):
        self.branches, self.else_body, self.line = branches, else_body, line


class WhileNode(ASTNode):
    def __init__(self, cond, body, line=None):
        self.cond, self.body, self.line = cond, body, line


class ForNode(ASTNode):
    def __init__(self, init, cond, update, body, line=None):
        self.init, self.cond, self.update, self.body, self.line = init, cond, update, body, line


class BreakNode(ASTNode):
    def __init__(self, line=None):
        self.line = line


class ContinueNode(ASTNode):
    def __init__(self, line=None):
        self.line = line


class FuncDeclNode(ASTNode):
    def __init__(self, name, params, body, line=None):
        self.name, self.params, self.body, self.line = name, params, body, line


class ClassDeclNode(ASTNode):
    def __init__(self, name, methods, line=None):
        # methods: list of FuncDeclNode (method bodies use `self` as an
        # ordinary first parameter, added automatically by the parser)
        self.name, self.methods, self.line = name, methods, line


class ImportNode(ASTNode):
    def __init__(self, name, path, line=None):
        self.name, self.path, self.line = name, path, line


class PyImportNode(ASTNode):
    """py_import name[.dotted.path] -- imports a real Python module by
    name at runtime (see run() for how scripts actually call into it)."""
    def __init__(self, module_path, line=None):
        self.module_path, self.line = module_path, line


class ReturnNode(ASTNode):
    def __init__(self, expr, line=None):
        self.expr, self.line = expr, line


class CallNode(ASTNode):
    def __init__(self, callee, args, line=None):
        self.callee, self.args, self.line = callee, args, line


class UnaryOpNode(ASTNode):
    def __init__(self, op, expr, line=None):
        self.op, self.expr, self.line = op, expr, line


class BinaryOpNode(ASTNode):
    def __init__(self, left, op, right, line=None):
        self.left, self.op, self.right, self.line = left, op, right, line


class LiteralNode(ASTNode):
    def __init__(self, val, line=None):
        self.val, self.line = val, line


class VarAccessNode(ASTNode):
    def __init__(self, name, line=None):
        self.name, self.line = name, line


class ListNode(ASTNode):
    def __init__(self, elems, line=None):
        self.elems, self.line = elems, line


class ObjectNode(ASTNode):
    def __init__(self, pairs, line=None):
        self.pairs, self.line = pairs, line


class MemberAccessNode(ASTNode):
    def __init__(self, obj, member, line=None):
        self.obj, self.member, self.line = obj, member, line


class IndexAccessNode(ASTNode):
    def __init__(self, obj, index, line=None):
        self.obj, self.index, self.line = obj, index, line


# =====================================================================
# PARSER (recursive descent, precedence climbing for expressions)
# =====================================================================

class Parser:
    def __init__(self, tokens):
        self.tokens = tokens
        self.pos = 0

    def peek(self, offset=0):
        idx = self.pos + offset
        return self.tokens[idx] if idx < len(self.tokens) else self.tokens[-1]

    def at_end(self):
        return self.peek().type == 'EOF'

    def consume(self, expected_type=None, expected_value=None):
        tok = self.peek()
        if tok.type == 'EOF' and expected_type != 'EOF':
            raise ParseError("Unexpected end of input", tok.line)
        if expected_type and tok.type != expected_type:
            raise ParseError(f"Expected {expected_type}, got {tok.type} ({tok.value!r})", tok.line)
        if expected_value and tok.value != expected_value:
            raise ParseError(f"Expected '{expected_value}', got '{tok.value}'", tok.line)
        self.pos += 1
        return tok

    def match_kw(self, *values):
        tok = self.peek()
        return tok.type == 'KEYWORD' and tok.value in values

    def match_op(self, *values):
        tok = self.peek()
        return tok.type == 'OP' and tok.value in values

    def opt_semi(self):
        if self.peek().type == 'SEMI':
            self.consume('SEMI')

    # ---- top level -----------------------------------------------------

    def parse(self):
        stmts = []
        while not self.at_end():
            stmts.append(self.parse_stmt())
        return ProgramNode(stmts)

    def parse_block(self):
        self.consume('LBRACE')
        body = []
        while not self.at_end() and self.peek().type != 'RBRACE':
            body.append(self.parse_stmt())
        self.consume('RBRACE')
        return body

    def parse_stmt(self):
        if self.match_kw('let'):
            return self.parse_var_decl()
        if self.match_kw('print'):
            return self.parse_print()
        if self.match_kw('if'):
            return self.parse_if()
        if self.match_kw('while'):
            return self.parse_while()
        if self.match_kw('for'):
            return self.parse_for()
        if self.match_kw('fn'):
            return self.parse_fn_decl()
        if self.match_kw('class'):
            return self.parse_class_decl()
        if self.match_kw('import'):
            return self.parse_import()
        if self.peek().type == 'IDENT' and self.peek().value == 'py_import' \
                and self.peek(1).type == 'IDENT':
            return self.parse_py_import()
        if self.match_kw('return'):
            return self.parse_return()
        if self.match_kw('break'):
            tok = self.consume('KEYWORD', 'break')
            self.opt_semi()
            return BreakNode(tok.line)
        if self.match_kw('continue'):
            tok = self.consume('KEYWORD', 'continue')
            self.opt_semi()
            return ContinueNode(tok.line)
        expr = self.parse_expr()
        self.opt_semi()
        return expr

    def parse_var_decl(self):
        line = self.peek().line
        self.consume('KEYWORD', 'let')
        name = self.consume('IDENT').value
        self.consume('OP', '=')
        val = self.parse_expr()
        self.opt_semi()
        return VarDeclNode(name, val, line)

    def parse_print(self):
        line = self.peek().line
        self.consume('KEYWORD', 'print')
        self.consume('LPAREN')
        val = self.parse_expr()
        self.consume('RPAREN')
        self.opt_semi()
        return PrintNode(val, line)

    def parse_if(self):
        line = self.peek().line
        self.consume('KEYWORD', 'if')
        self.consume('LPAREN')
        cond = self.parse_expr()
        self.consume('RPAREN')
        body = self.parse_block()
        branches = [(cond, body)]
        else_body = None
        while self.match_kw('else'):
            self.consume('KEYWORD', 'else')
            if self.match_kw('if'):
                self.consume('KEYWORD', 'if')
                self.consume('LPAREN')
                c2 = self.parse_expr()
                self.consume('RPAREN')
                branches.append((c2, self.parse_block()))
            else:
                else_body = self.parse_block()
                break
        self.opt_semi()
        return IfNode(branches, else_body, line)

    def parse_while(self):
        line = self.peek().line
        self.consume('KEYWORD', 'while')
        self.consume('LPAREN')
        cond = self.parse_expr()
        self.consume('RPAREN')
        body = self.parse_block()
        self.opt_semi()
        return WhileNode(cond, body, line)

    def parse_for(self):
        line = self.peek().line
        self.consume('KEYWORD', 'for')
        self.consume('LPAREN')
        init = None
        if self.peek().type != 'SEMI':
            init = self.parse_var_decl() if self.match_kw('let') else self.parse_expr()
        else:
            self.consume('SEMI')
        if not isinstance(init, VarDeclNode):
            pass
        # after parse_var_decl or bare expr statement, semicolon already
        # consumed by opt_semi() inside those helpers only for statements;
        # parse_expr() alone does not consume it, so handle explicitly:
        if self.peek().type == 'SEMI':
            self.consume('SEMI')
        cond = None
        if self.peek().type != 'SEMI':
            cond = self.parse_expr()
        self.consume('SEMI')
        update = None
        if self.peek().type != 'RPAREN':
            update = self.parse_expr()
        self.consume('RPAREN')
        body = self.parse_block()
        self.opt_semi()
        return ForNode(init, cond, update, body, line)

    def parse_fn_decl(self):
        line = self.peek().line
        self.consume('KEYWORD', 'fn')
        name = self.consume('IDENT').value
        self.consume('LPAREN')
        params = []
        if self.peek().type != 'RPAREN':
            params.append(self.consume('IDENT').value)
            while self.peek().type == 'COMMA':
                self.consume('COMMA')
                params.append(self.consume('IDENT').value)
        self.consume('RPAREN')
        body = self.parse_block()
        self.opt_semi()
        return FuncDeclNode(name, params, body, line)

    def parse_class_decl(self):
        line = self.peek().line
        self.consume('KEYWORD', 'class')
        name = self.consume('IDENT').value
        self.consume('LBRACE')
        methods = []
        seen = set()
        while not self.at_end() and self.peek().type != 'RBRACE':
            if not self.match_kw('fn'):
                tok = self.peek()
                raise ParseError(
                    f"Expected a method ('fn ...') inside class '{name}', got {tok.type} ({tok.value!r})",
                    tok.line)
            m = self.parse_fn_decl()
            if m.name in seen:
                raise ParseError(f"method '{m.name}' declared more than once in class '{name}'", m.line)
            seen.add(m.name)
            methods.append(m)
        self.consume('RBRACE')
        self.opt_semi()
        return ClassDeclNode(name, methods, line)

    def parse_import(self):
        line = self.peek().line
        self.consume('KEYWORD', 'import')
        name = self.consume('IDENT').value
        self.consume('KEYWORD', 'from')
        path_tok = self.consume('STRING')
        self.opt_semi()
        return ImportNode(name, path_tok.value, line)

    def parse_py_import(self):
        line = self.peek().line
        self.consume('IDENT')  # the literal word "py_import" (contextual,
                                # not a reserved keyword -- see parse_stmt)
        parts = [self.consume('IDENT').value]
        while self.peek().type == 'DOT':
            self.consume('DOT')
            parts.append(self.consume('IDENT').value)
        self.opt_semi()
        return PyImportNode('.'.join(parts), line)

    def parse_return(self):
        line = self.peek().line
        self.consume('KEYWORD', 'return')
        expr = None
        if self.peek().type not in ('SEMI', 'RBRACE') and not self.at_end():
            expr = self.parse_expr()
        self.opt_semi()
        return ReturnNode(expr, line)

    # ---- expressions (lowest to highest precedence) --------------------

    def parse_expr(self):
        return self.parse_assignment()

    def parse_assignment(self):
        left = self.parse_or()
        if self.match_op('='):
            line = self.peek().line
            self.consume('OP', '=')
            if not isinstance(left, (VarAccessNode, MemberAccessNode, IndexAccessNode)):
                raise ParseError("Invalid assignment target", line)
            return AssignNode(left, self.parse_assignment(), line)
        return left

    def parse_or(self):
        left = self.parse_and()
        while self.match_op('||') or self.match_kw('or'):
            line = self.peek().line
            self.consume()
            left = BinaryOpNode(left, '||', self.parse_and(), line)
        return left

    def parse_and(self):
        left = self.parse_equality()
        while self.match_op('&&') or self.match_kw('and'):
            line = self.peek().line
            self.consume()
            left = BinaryOpNode(left, '&&', self.parse_equality(), line)
        return left

    def parse_equality(self):
        left = self.parse_comparison()
        while self.match_op('==', '!='):
            line = self.peek().line
            op = self.consume('OP').value
            left = BinaryOpNode(left, op, self.parse_comparison(), line)
        return left

    def parse_comparison(self):
        left = self.parse_additive()
        while self.match_op('<', '>', '<=', '>='):
            line = self.peek().line
            op = self.consume('OP').value
            left = BinaryOpNode(left, op, self.parse_additive(), line)
        return left

    def parse_additive(self):
        left = self.parse_multiplicative()
        while self.match_op('+', '-'):
            line = self.peek().line
            op = self.consume('OP').value
            left = BinaryOpNode(left, op, self.parse_multiplicative(), line)
        return left

    def parse_multiplicative(self):
        left = self.parse_unary()
        while self.match_op('*', '/', '%'):
            line = self.peek().line
            op = self.consume('OP').value
            left = BinaryOpNode(left, op, self.parse_unary(), line)
        return left

    def parse_unary(self):
        if self.match_op('-'):
            line = self.peek().line
            self.consume('OP', '-')
            return UnaryOpNode('-', self.parse_unary(), line)
        if self.match_op('!') or self.match_kw('not'):
            line = self.peek().line
            self.consume()
            return UnaryOpNode('!', self.parse_unary(), line)
        return self.parse_postfix()

    def parse_postfix(self):
        expr = self.parse_primary()
        while True:
            tok = self.peek()
            if tok.type == 'DOT':
                self.consume('DOT')
                member = self.consume('IDENT').value
                expr = MemberAccessNode(expr, member, tok.line)
            elif tok.type == 'LBRACK':
                self.consume('LBRACK')
                idx = self.parse_expr()
                self.consume('RBRACK')
                expr = IndexAccessNode(expr, idx, tok.line)
            elif tok.type == 'LPAREN':
                self.consume('LPAREN')
                args = []
                if self.peek().type != 'RPAREN':
                    args.append(self.parse_expr())
                    while self.peek().type == 'COMMA':
                        self.consume('COMMA')
                        args.append(self.parse_expr())
                self.consume('RPAREN')
                expr = CallNode(expr, args, tok.line)
            else:
                break
        return expr

    def parse_primary(self):
        tok = self.peek()
        if tok.type == 'NUMBER':
            self.consume()
            return LiteralNode(float(tok.value) if '.' in tok.value else int(tok.value), tok.line)
        if tok.type == 'STRING':
            self.consume()
            return LiteralNode(tok.value, tok.line)
        if self.match_kw('true', 'false'):
            self.consume()
            return LiteralNode(tok.value == 'true', tok.line)
        if self.match_kw('null'):
            self.consume()
            return LiteralNode(None, tok.line)
        if tok.type == 'IDENT':
            self.consume()
            return VarAccessNode(tok.value, tok.line)
        if tok.type == 'LPAREN':
            self.consume('LPAREN')
            e = self.parse_expr()
            self.consume('RPAREN')
            return e
        if tok.type == 'LBRACK':
            self.consume('LBRACK')
            elems = []
            if self.peek().type != 'RBRACK':
                elems.append(self.parse_expr())
                while self.peek().type == 'COMMA':
                    self.consume('COMMA')
                    elems.append(self.parse_expr())
            self.consume('RBRACK')
            return ListNode(elems, tok.line)
        if tok.type == 'LBRACE':
            self.consume('LBRACE')
            pairs = []
            if self.peek().type != 'RBRACE':
                k = self._parse_obj_key()
                self.consume('COLON')
                pairs.append((k, self.parse_expr()))
                while self.peek().type == 'COMMA':
                    self.consume('COMMA')
                    k = self._parse_obj_key()
                    self.consume('COLON')
                    pairs.append((k, self.parse_expr()))
            self.consume('RBRACE')
            return ObjectNode(pairs, tok.line)
        raise ParseError(f"Unexpected token: {tok.type} ({tok.value!r})", tok.line)

    def _parse_obj_key(self):
        tok = self.peek()
        if tok.type in ('IDENT', 'KEYWORD'):
            self.consume()
            return tok.value
        if tok.type == 'STRING':
            self.consume()
            return tok.value
        raise ParseError(f"Expected object key, got {tok.type}", tok.line)


# =====================================================================
# 3. COMPILER (AST -> CVM bytecode)
# =====================================================================

BIN_OPS = {
    '+': 'ADD', '-': 'SUB', '*': 'MUL', '/': 'DIV', '%': 'MOD',
    '==': 'EQ', '!=': 'NEQ', '<': 'LT', '>': 'GT', '<=': 'LTE', '>=': 'GTE',
}


class Instr:
    __slots__ = ("op", "arg_type", "arg_val", "extra", "line")

    def __init__(self, op, arg_type, arg_val, extra, line):
        self.op, self.arg_type, self.arg_val, self.extra, self.line = op, arg_type, arg_val, extra, line


class FuncMeta:
    def __init__(self, name, params, addr):
        self.name, self.params, self.addr = name, params, addr


class LoopCtx:
    """Tracks patch points for break/continue inside one loop."""
    def __init__(self, continue_target=None):
        self.break_jumps = []
        self.continue_jumps = []
        self.continue_target = continue_target  # set immediately if known


class BinaryCompiler:
    def __init__(self):
        self.instructions = []
        self.strings = []
        self._string_index = {}
        self.loop_stack = []
        self.functions = {}
        self.classes = {}   # class name -> {method_name: arity (excluding self)}
        self.current_func_params = None  # set of param names while compiling a fn body

    def add_string(self, s):
        if s in self._string_index:
            return self._string_index[s]
        idx = len(self.strings)
        self.strings.append(s)
        self._string_index[s] = idx
        return idx

    def emit(self, opcode_name, arg_type=ARG_NONE, arg_val=0, extra=0, line=None):
        idx = len(self.instructions)
        self.instructions.append(Instr(OPCODES[opcode_name], arg_type, arg_val, extra, line))
        return idx

    def here(self):
        return len(self.instructions)

    def patch(self, idx, target):
        self.instructions[idx].arg_val = target

    # ---- program structure ---------------------------------------------

    def compile_program(self, node):
        fn_decls = [s for s in node.stmts if isinstance(s, FuncDeclNode)]
        class_decls = [s for s in node.stmts if isinstance(s, ClassDeclNode)]
        import_decls = [s for s in node.stmts if isinstance(s, ImportNode)]
        top_stmts = [s for s in node.stmts if not isinstance(
            s, (FuncDeclNode, ClassDeclNode, ImportNode))]

        class_names = {c.name for c in class_decls}
        seen = set()
        for fn in fn_decls:
            if fn.name in seen:
                raise CompileError(f"function '{fn.name}' declared more than once", fn.line)
            if fn.name in class_names or fn.name in self.classes:
                raise CompileError(f"'{fn.name}' is already declared as a class", fn.line)
            seen.add(fn.name)

        for cls in class_decls:
            if cls.name in self.classes:
                raise CompileError(f"class '{cls.name}' declared more than once", cls.line)
            if cls.name in seen or cls.name in self.functions:
                raise CompileError(
                    f"'{cls.name}' is already declared as a function", cls.line)
            self.classes[cls.name] = {m.name: len(m.params) for m in cls.methods}

        # Mangle every class method into an ordinary function named
        # "ClassName.method", with `self` prepended as its first parameter.
        # This lets methods reuse all the existing function-compilation
        # machinery (recursion, mutual calls, the CALL opcode, etc.)
        # unchanged -- a method is just a function with an extra parameter.
        mangled_fn_decls = list(fn_decls)
        for cls in class_decls:
            for m in cls.methods:
                mangled_name = f"{cls.name}.{m.name}"
                if mangled_name in seen:
                    raise CompileError(f"function '{mangled_name}' declared more than once", m.line)
                seen.add(mangled_name)
                mangled_fn_decls.append(
                    FuncDeclNode(mangled_name, ["self"] + m.params, m.body, m.line))
        fn_decls = mangled_fn_decls

        # Emit the skip-past-functions jump unconditionally, before any
        # function bodies (local or imported) are emitted, so nothing --
        # not even a spliced-in imported module's own top-level statements
        # -- is ever reachable by simple fallthrough. Its target is
        # patched once we know exactly where real top-level code starts.
        skip_idx = self.emit("JUMP", ARG_IMM, 0)

        # Imports are resolved and merged in next (splicing in the
        # imported module's compiled instructions, entirely behind the
        # jump above), so an imported class's methods behave exactly like
        # ones declared locally from here on.
        for imp in import_decls:
            self._process_import(imp)

        # Pre-register addresses with a placeholder pass so functions can
        # call each other and themselves (recursion) regardless of order.
        # Register each name in the string table now (even if the function
        # is never called) so assemble() can always find it when writing
        # the function table.
        for fn in fn_decls:
            self.functions[fn.name] = FuncMeta(fn.name, fn.params, None)
            self.add_string(fn.name)
        for fn in fn_decls:
            self.functions[fn.name].addr = self.here()
            self._compile_function_body(fn)

        self.patch(skip_idx, self.here())

        for s in top_stmts:
            self.compile(s)
        self.emit("HALT")

    def _process_import(self, imp):
        """import ClassName from "file.cvm"; -- load a separately compiled
        .cvm file and splice the named class's compiled methods (or a
        plain function of the same name) into this module, at compile
        time, so the resulting .cvm is fully self-contained."""
        try:
            with open(imp.path, "rb") as f:
                data = f.read()
        except OSError as e:
            raise CompileError(f"cannot read import '{imp.path}': {e}", imp.line)
        try:
            module = load_module(data)
        except CRTError as e:
            raise CompileError(f"cannot load import '{imp.path}': {e.format()}", imp.line)

        prefix = imp.name + "."
        wanted = {name: meta for name, meta in module.functions.items()
                  if name == imp.name or name.startswith(prefix)}
        if not wanted:
            raise CompileError(
                f"'{imp.name}' not found in '{imp.path}' (no matching function or class)", imp.line)
        if imp.name in self.functions or imp.name in self.classes:
            raise CompileError(f"'{imp.name}' is already defined", imp.line)

        # Splice the foreign module's instructions onto the end of ours.
        # String indices and jump-target addresses inside the copied
        # instructions are rewritten to point into *this* module's tables.
        base_addr = len(self.instructions)
        str_remap = [self.add_string(s) for s in module.strings]
        for ins in module.instructions:
            arg_val = ins.arg_val
            if ins.arg_type == ARG_STR:
                arg_val = str_remap[arg_val]
            elif REV_OPCODES.get(ins.op) in ("JUMP", "JUMP_IF_FALSE", "JUMP_IF_TRUE"):
                arg_val = arg_val + base_addr
            self.instructions.append(Instr(ins.op, ins.arg_type, arg_val, ins.extra, ins.line))

        methods = {}
        for name, (addr, arity) in wanted.items():
            self.functions[name] = FuncMeta(name, [None] * arity, addr + base_addr)
            self.add_string(name)
            if name.startswith(prefix):
                methods[name[len(prefix):]] = arity - 1  # drop the implicit self

        if methods:
            self.classes[imp.name] = methods

    def _compile_function_body(self, fn):
        self.emit("MAKE_FRAME", ARG_IMM, len(fn.params), line=fn.line)
        for p in reversed(fn.params):
            s_idx = self.add_string(p)
            self.emit("STORE_LOCAL", ARG_STR, s_idx, line=fn.line)
        for s in fn.body:
            self.compile(s)
        self.emit("PUSH_NULL", line=fn.line)
        self.emit("RET", line=fn.line)

    # ---- statements / expressions ---------------------------------------

    def compile(self, node):
        if isinstance(node, LiteralNode):
            self._lit(node)
        elif isinstance(node, VarAccessNode):
            self.emit("LOAD", ARG_STR, self.add_string(node.name), line=node.line)
        elif isinstance(node, VarDeclNode):
            self.compile(node.val)
            self.emit("STORE_LOCAL", ARG_STR, self.add_string(node.name), line=node.line)
        elif isinstance(node, AssignNode):
            self._assign(node)
        elif isinstance(node, UnaryOpNode):
            self.compile(node.expr)
            self.emit("NEG" if node.op == '-' else "NOT", line=node.line)
        elif isinstance(node, BinaryOpNode):
            self._binop(node)
        elif isinstance(node, PrintNode):
            self.compile(node.expr)
            self.emit("PRINT", line=node.line)
        elif isinstance(node, IfNode):
            self._if(node)
        elif isinstance(node, WhileNode):
            self._while(node)
        elif isinstance(node, ForNode):
            self._for(node)
        elif isinstance(node, BreakNode):
            if not self.loop_stack:
                raise CompileError("'break' outside of a loop", node.line)
            idx = self.emit("JUMP", ARG_IMM, 0, line=node.line)
            self.loop_stack[-1].break_jumps.append(idx)
        elif isinstance(node, ContinueNode):
            if not self.loop_stack:
                raise CompileError("'continue' outside of a loop", node.line)
            ctx = self.loop_stack[-1]
            if ctx.continue_target is not None:
                self.emit("JUMP", ARG_IMM, ctx.continue_target, line=node.line)
            else:
                idx = self.emit("JUMP", ARG_IMM, 0, line=node.line)
                ctx.continue_jumps.append(idx)
        elif isinstance(node, FuncDeclNode):
            raise CompileError("functions can only be declared at the top level", node.line)
        elif isinstance(node, ReturnNode):
            self.compile(node.expr) if node.expr is not None else self.emit("PUSH_NULL", line=node.line)
            self.emit("RET", line=node.line)
        elif isinstance(node, CallNode):
            self._call(node)
        elif isinstance(node, ListNode):
            for e in node.elems:
                self.compile(e)
            self.emit("MAKE_LIST", ARG_IMM, len(node.elems), line=node.line)
        elif isinstance(node, ObjectNode):
            for k, v in node.pairs:
                self.emit("PUSH_STR", ARG_STR, self.add_string(k), line=node.line)
                self.compile(v)
            self.emit("MAKE_OBJECT", ARG_IMM, len(node.pairs), line=node.line)
        elif isinstance(node, MemberAccessNode):
            self.compile(node.obj)
            self.emit("GET_MEMBER", ARG_STR, self.add_string(node.member), line=node.line)
        elif isinstance(node, IndexAccessNode):
            self.compile(node.obj)
            self.compile(node.index)
            self.emit("GET_INDEX", line=node.line)
        elif isinstance(node, PyImportNode):
            self.emit("PY_IMPORT", ARG_STR, self.add_string(node.module_path), line=node.line)
        else:
            raise CompileError(f"Cannot compile node: {type(node).__name__}", node.line)

    def _lit(self, node):
        v = node.val
        if isinstance(v, bool):
            self.emit("PUSH_BOOL", ARG_IMM, 1 if v else 0, line=node.line)
        elif v is None:
            self.emit("PUSH_NULL", line=node.line)
        elif isinstance(v, int):
            self.emit("PUSH_INT", ARG_IMM, v, line=node.line)
        elif isinstance(v, float):
            self.emit("PUSH_FLOAT", ARG_STR, self.add_string(repr(v)), line=node.line)
        elif isinstance(v, str):
            self.emit("PUSH_STR", ARG_STR, self.add_string(v), line=node.line)

    def _assign(self, node):
        target = node.target
        if isinstance(target, VarAccessNode):
            self.compile(node.val)
            self.emit("STORE", ARG_STR, self.add_string(target.name), line=node.line)
        elif isinstance(target, MemberAccessNode):
            self.compile(target.obj)
            self.compile(node.val)
            self.emit("SET_MEMBER", ARG_STR, self.add_string(target.member), line=node.line)
        elif isinstance(target, IndexAccessNode):
            self.compile(target.obj)
            self.compile(target.index)
            self.compile(node.val)
            self.emit("SET_INDEX", line=node.line)
        else:
            raise CompileError("Invalid assignment target", node.line)

    def _binop(self, node):
        if node.op == '&&':
            self.compile(node.left)
            self.emit("DUP", line=node.line)
            jf = self.emit("JUMP_IF_FALSE", ARG_IMM, 0, line=node.line)
            self.emit("POP", line=node.line)
            self.compile(node.right)
            self.patch(jf, self.here())
            return
        if node.op == '||':
            self.compile(node.left)
            self.emit("DUP", line=node.line)
            jt = self.emit("JUMP_IF_TRUE", ARG_IMM, 0, line=node.line)
            self.emit("POP", line=node.line)
            self.compile(node.right)
            self.patch(jt, self.here())
            return
        self.compile(node.left)
        self.compile(node.right)
        self.emit(BIN_OPS[node.op], line=node.line)

    def _if(self, node):
        end_jumps = []
        n = len(node.branches)
        for i, (cond, body) in enumerate(node.branches):
            self.compile(cond)
            jf = self.emit("JUMP_IF_FALSE", ARG_IMM, 0, line=cond.line)
            for s in body:
                self.compile(s)
            if node.else_body is not None or i < n - 1:
                end_jumps.append(self.emit("JUMP", ARG_IMM, 0, line=node.line))
            self.patch(jf, self.here())
        if node.else_body is not None:
            for s in node.else_body:
                self.compile(s)
        for j in end_jumps:
            self.patch(j, self.here())

    def _while(self, node):
        loop_start = self.here()
        self.compile(node.cond)
        jf = self.emit("JUMP_IF_FALSE", ARG_IMM, 0, line=node.line)
        ctx = LoopCtx(continue_target=loop_start)
        self.loop_stack.append(ctx)
        for s in node.body:
            self.compile(s)
        self.emit("JUMP", ARG_IMM, loop_start, line=node.line)
        end = self.here()
        self.patch(jf, end)
        self.loop_stack.pop()
        for b in ctx.break_jumps:
            self.patch(b, end)

    def _for(self, node):
        if node.init is not None:
            self.compile(node.init)
        loop_start = self.here()
        jf = None
        if node.cond is not None:
            self.compile(node.cond)
            jf = self.emit("JUMP_IF_FALSE", ARG_IMM, 0, line=node.line)
        # continue must run the update step before re-checking the condition,
        # so continue jumps are patched to the update address once known.
        ctx = LoopCtx(continue_target=None)
        self.loop_stack.append(ctx)
        for s in node.body:
            self.compile(s)
        update_addr = self.here()
        if node.update is not None:
            self.compile(node.update)
        self.emit("JUMP", ARG_IMM, loop_start, line=node.line)
        end = self.here()
        if jf is not None:
            self.patch(jf, end)
        self.loop_stack.pop()
        for c in ctx.continue_jumps:
            self.patch(c, update_addr)
        for b in ctx.break_jumps:
            self.patch(b, end)

    def _call(self, node):
        # ClassName.method(args) -- a static, compile-time-resolved call
        # into a class's method table (used for imported "library" classes
        # called like a namespace: Mathy.add(1, 2)).
        if isinstance(node.callee, MemberAccessNode) and isinstance(node.callee.obj, VarAccessNode) \
                and node.callee.obj.name in self.classes:
            cls_name = node.callee.obj.name
            method = node.callee.member
            methods = self.classes[cls_name]
            if method not in methods:
                raise CompileError(f"class '{cls_name}' has no method '{method}'", node.line)
            arity = methods[method]
            if len(node.args) != arity:
                raise CompileError(
                    f"'{cls_name}.{method}' takes {arity} argument(s), got {len(node.args)}", node.line)
            mangled = f"{cls_name}.{method}"
            # Static calls don't pass a real instance -- push a fresh empty
            # `self` so the method body can still use self.x for scratch
            # state if it wants to, without requiring a constructed object.
            # SET_MEMBER consumes its object operand, so DUP first: one
            # copy gets tagged and thrown away by SET_MEMBER, the other is
            # what actually gets passed in as `self`.
            self.emit("MAKE_OBJECT", ARG_IMM, 0, line=node.line)
            self.emit("DUP", line=node.line)
            self.emit("PUSH_STR", ARG_STR, self.add_string(cls_name), line=node.line)
            self.emit("SET_MEMBER", ARG_STR, self.add_string("__class__"), line=node.line)
            for a in node.args:
                self.compile(a)
            self.emit("CALL", ARG_STR, self.add_string(mangled),
                      extra=len(node.args) + 1, line=node.line)
            return

        # obj.method(args) where obj isn't a known class name -- a dynamic
        # instance method call. Resolved at runtime via the object's
        # __class__ field, since the same call site could see different
        # kinds of objects (or none at all, in which case it's a runtime
        # error rather than a compile-time one).
        if isinstance(node.callee, MemberAccessNode):
            self.compile(node.callee.obj)
            for a in node.args:
                self.compile(a)
            self.emit("CALL_METHOD", ARG_STR, self.add_string(node.callee.member),
                      extra=len(node.args), line=node.line)
            return

        if not isinstance(node.callee, VarAccessNode):
            raise CompileError("Only named functions can be called", node.line)
        name = node.callee.name

        # ClassName(args) -- construct a new instance: build a fresh
        # object tagged with __class__, run its "new" method (if any) for
        # side effects on `self`, and leave the object on the stack.
        if name in self.classes:
            methods = self.classes[name]
            self.emit("MAKE_OBJECT", ARG_IMM, 0, line=node.line)
            self.emit("DUP", line=node.line)
            self.emit("PUSH_STR", ARG_STR, self.add_string(name), line=node.line)
            self.emit("SET_MEMBER", ARG_STR, self.add_string("__class__"), line=node.line)
            if "new" in methods:
                arity = methods["new"]
                if len(node.args) != arity:
                    raise CompileError(
                        f"'{name}.new' takes {arity} argument(s), got {len(node.args)}", node.line)
                self.emit("DUP", line=node.line)          # keep the instance under the call
                for a in node.args:
                    self.compile(a)
                self.emit("CALL", ARG_STR, self.add_string(f"{name}.new"),
                          extra=len(node.args) + 1, line=node.line)
                self.emit("POP", line=node.line)          # discard new()'s return value
            elif node.args:
                raise CompileError(f"class '{name}' has no constructor 'new' to take arguments", node.line)
            return

        if name in BUILTINS:
            for a in node.args:
                self.compile(a)
            self.emit("CALL_BUILTIN", ARG_STR, self.add_string(name),
                      extra=len(node.args), line=node.line)
            return
        if name in GFX_BUILTINS:
            expected = GFX_BUILTINS[name]
            allowed = expected if isinstance(expected, tuple) else (expected,)
            if len(node.args) not in allowed:
                choices = " or ".join(str(n) for n in allowed)
                raise CompileError(
                    f"'{name}' takes {choices} argument(s), got {len(node.args)}", node.line)
            for a in node.args:
                self.compile(a)
            self.emit("CALL_GFX", ARG_STR, self.add_string(name),
                      extra=len(node.args), line=node.line)
            return
        for a in node.args:
            self.compile(a)
        self.emit("CALL", ARG_STR, self.add_string(name),
                  extra=len(node.args), line=node.line)

    def assemble(self):
        out = bytearray(b"CVM\x04")
        out.extend(struct.pack(">H", len(self.strings)))
        for s in self.strings:
            enc = s.encode('utf-8')
            out.extend(struct.pack(">H", len(enc)))
            out.extend(enc)
        out.extend(struct.pack(">I", len(self.instructions)))
        for ins in self.instructions:
            out.extend(struct.pack(">BBih", ins.op, ins.arg_type, ins.arg_val, ins.extra))
        # Function table: the instruction stream alone doesn't record which
        # name owns which MAKE_FRAME address (that mapping only exists in
        # the compiler's `functions` dict), so persist it here as
        # (name string-index, entry address, param count) triples. This
        # lets the loader resolve CALL targets by name instead of guessing
        # from call order (which breaks for self-recursive functions), and
        # lets the runtime give a clear "wrong number of arguments" error
        # instead of a raw stack underflow.
        out.extend(struct.pack(">H", len(self.functions)))
        for meta in self.functions.values():
            out.extend(struct.pack(">HIH", self._string_index[meta.name], meta.addr, len(meta.params)))
        # Line-number table: one i32 per instruction (-1 = unknown), so
        # runtime errors loaded from a .cvm file can still report a source
        # line instead of always saying "line: unknown". Run-length encoded
        # as (count, line) pairs since runs of same-line instructions are
        # common (e.g. a whole expression compiles to several instructions
        # that all share one line).
        runs = []
        for ins in self.instructions:
            line = ins.line if ins.line is not None else -1
            if runs and runs[-1][1] == line:
                runs[-1][0] += 1
            else:
                runs.append([1, line])
        out.extend(struct.pack(">I", len(runs)))
        for count, line in runs:
            out.extend(struct.pack(">Ii", count, line))
        return bytes(out)


def compile_source(code):
    """Convenience: source text -> assembled CVM bytecode bytes."""
    tokens = tokenize(code)
    ast = Parser(tokens).parse()
    compiler = BinaryCompiler()
    # resolve forward function calls by pre-scanning names (handled inside
    # compile_program via two passes), then verify all called names exist.
    compiler.compile_program(ast)
    _verify_calls(ast, compiler)
    return compiler.assemble()


def _verify_calls(ast, compiler):
    """Walk the AST and raise a clear CompileError for calls to unknown
    functions (that aren't built-ins), instead of failing at runtime."""
    known = set(compiler.functions.keys())

    def walk(node):
        if isinstance(node, ProgramNode):
            for s in node.stmts:
                walk(s)
        elif isinstance(node, CallNode):
            if isinstance(node.callee, VarAccessNode):
                nm = node.callee.name
                if nm not in BUILTINS and nm not in GFX_BUILTINS and nm not in known \
                        and nm not in compiler.classes:
                    raise CompileError(f"call to undefined function '{nm}'", node.line)
            elif isinstance(node.callee, MemberAccessNode):
                walk(node.callee.obj)
            for a in node.args:
                walk(a)
        elif isinstance(node, FuncDeclNode):
            for s in node.body:
                walk(s)
        elif isinstance(node, ClassDeclNode):
            for m in node.methods:
                for s in m.body:
                    walk(s)
        elif isinstance(node, ImportNode):
            pass  # validity of the imported name is checked at compile time
        elif isinstance(node, PyImportNode):
            pass  # nothing to check here; the module path is just a string
                  # and any failure to actually import it is a runtime error
        elif isinstance(node, (VarDeclNode,)):
            walk(node.val)
        elif isinstance(node, AssignNode):
            walk(node.target)
            walk(node.val)
        elif isinstance(node, PrintNode):
            walk(node.expr)
        elif isinstance(node, IfNode):
            for c, b in node.branches:
                walk(c)
                for s in b:
                    walk(s)
            if node.else_body:
                for s in node.else_body:
                    walk(s)
        elif isinstance(node, WhileNode):
            walk(node.cond)
            for s in node.body:
                walk(s)
        elif isinstance(node, ForNode):
            if node.init: walk(node.init)
            if node.cond: walk(node.cond)
            if node.update: walk(node.update)
            for s in node.body:
                walk(s)
        elif isinstance(node, ReturnNode):
            if node.expr: walk(node.expr)
        elif isinstance(node, (UnaryOpNode,)):
            walk(node.expr)
        elif isinstance(node, BinaryOpNode):
            walk(node.left)
            walk(node.right)
        elif isinstance(node, ListNode):
            for e in node.elems:
                walk(e)
        elif isinstance(node, ObjectNode):
            for k, v in node.pairs:
                walk(v)
        elif isinstance(node, MemberAccessNode):
            walk(node.obj)
        elif isinstance(node, IndexAccessNode):
            walk(node.obj)
            walk(node.index)
        # LiteralNode, VarAccessNode, BreakNode, ContinueNode: nothing to check

    walk(ast)


# =====================================================================
# 3b. ASSEMBLER (CRT assembly text -> CVM bytecode)
# =====================================================================
#
# A human-writable text format for CVM bytecode, for people who want to
# hand-write or generate bytecode directly instead of going through the
# CRT language front-end. Mirrors what `crt disasm` prints closely enough
# that a disassembly is a short edit away from valid input.
#
# SYNTAX
#   ; a comment, to end of line
#   label:                       define a label (address of the *next*
#                                 instruction) -- used as a jump target
#   .func name arity             mark the next instruction's address as
#                                 the entry point of function `name`,
#                                 taking `arity` parameters
#   MNEMONIC                     instruction with no operand
#   MNEMONIC 42                  instruction with an integer operand
#   MNEMONIC "text"               instruction with a string operand
#                                  (interned into the string table)
#   MNEMONIC 3.5                   PUSH_FLOAT's operand is written as a
#                                    float literal, stored the same way
#                                    the compiler stores one (as a string)
#   MNEMONIC label                 a label used as a jump target, e.g.
#                                    JUMP loop_start
#   MNEMONIC "name", 2              string operand plus an extra field
#                                    (argc), e.g. CALL "add", 2
#
# Any bare identifier operand that isn't a known label at assemble time
# is an error (undefined label), so typos are caught rather than silently
# assembled as address 0.

class AsmError(CRTError):
    pass


_ASM_TOKEN_TYPES = [
    ("COMMENT",  r';[^\n]*'),
    ("NEWLINE",  r'\n'),
    ("STRING",   r'"(?:\\.|[^"\\])*"'),
    ("FLOAT",    r'-?\d+\.\d+'),
    ("INT",      r'-?\d+'),
    ("DIRECTIVE", r'\.[a-zA-Z_][a-zA-Z0-9_]*'),
    # Labels/identifiers may contain dots after the first character, so
    # mangled class method names (e.g. "Counter.new") can be used as
    # both function-table names (in string operands) and jump/def labels.
    # The leading character still can't be a dot -- that's DIRECTIVE's
    # job (.func etc.) -- and a dot can't be the last character either,
    # so "foo." doesn't swallow a following ":"/"," by accident.
    ("LABELDEF", r'[a-zA-Z_][a-zA-Z0-9_]*(?:\.[a-zA-Z_][a-zA-Z0-9_]*)*:'),
    ("IDENT",    r'[a-zA-Z_][a-zA-Z0-9_]*(?:\.[a-zA-Z_][a-zA-Z0-9_]*)*'),
    ("COMMA",    r','),
    ("SKIP",     r'[ \t\r]+'),
    ("MISMATCH", r'.'),
]

_ASM_TOKEN_RE = re.compile(
    '|'.join(f'(?P<{name}>{pattern})' for name, pattern in _ASM_TOKEN_TYPES),
    re.DOTALL,
)


class AsmToken:
    __slots__ = ("type", "value", "line")

    def __init__(self, type_, value, line):
        self.type, self.value, self.line = type_, value, line


def _asm_tokenize(text):
    tokens = []
    line = 1
    pos = 0
    length = len(text)
    while pos < length:
        m = _ASM_TOKEN_RE.match(text, pos)
        if not m:
            raise AsmError(f"unexpected character: {text[pos]!r}", line)
        kind = m.lastgroup
        value = m.group()
        pos = m.end()
        if kind == 'NEWLINE':
            tokens.append(AsmToken('NEWLINE', None, line))
            line += 1
            continue
        if kind in ('SKIP', 'COMMENT'):
            continue
        if kind == 'MISMATCH':
            raise AsmError(f"unexpected character: {value!r}", line)
        if kind == 'STRING':
            value = _unescape(value[1:-1])
        elif kind == 'LABELDEF':
            value = value[:-1]
        tokens.append(AsmToken(kind, value, line))
    tokens.append(AsmToken('EOF', None, line))
    return tokens


class Assembler:
    """Parses CRT assembly text and produces the same kind of assembled
    bytes BinaryCompiler.assemble() does, so the output is a drop-in
    .cvm file usable by `crt exec` / `crt disasm` / the REPL loader."""

    def __init__(self):
        self.instructions = []   # list of Instr
        self.strings = []
        self._string_index = {}
        self.functions = {}      # name -> FuncMeta
        self._pending_func = None  # (name, arity) waiting for the next instruction's address
        self._labels = {}          # name -> resolved address (once seen as a def)
        self._label_uses = []      # (instr_index, label_name, line) needing patching

    def add_string(self, s):
        if s in self._string_index:
            return self._string_index[s]
        idx = len(self.strings)
        self.strings.append(s)
        self._string_index[s] = idx
        return idx

    def here(self):
        return len(self.instructions)

    def assemble_text(self, text):
        tokens = _asm_tokenize(text)
        pos = 0

        def peek(off=0):
            i = pos + off
            return tokens[i] if i < len(tokens) else tokens[-1]

        while True:
            tok = peek()
            if tok.type == 'EOF':
                break
            if tok.type == 'NEWLINE':
                pos += 1
                continue
            if tok.type == 'LABELDEF':
                name = tok.value
                if name in self._labels:
                    raise AsmError(f"label '{name}' defined more than once", tok.line)
                self._labels[name] = self.here()
                if self._pending_func is not None:
                    fname, arity = self._pending_func
                    self.functions[fname] = FuncMeta(fname, [None] * arity, self.here())
                    self.add_string(fname)
                    self._pending_func = None
                pos += 1
                continue
            if tok.type == 'DIRECTIVE':
                pos = self._parse_directive(tokens, pos)
                continue
            if tok.type == 'IDENT':
                pos = self._parse_instruction(tokens, pos)
                continue
            raise AsmError(f"unexpected token {tok.type} ({tok.value!r})", tok.line)

        if self._pending_func is not None:
            fname, arity = self._pending_func
            self.functions[fname] = FuncMeta(fname, [None] * arity, self.here())
            self.add_string(fname)

        # Resolve label references now that every label has been seen.
        for instr_idx, label_name, line in self._label_uses:
            if label_name not in self._labels:
                raise AsmError(f"undefined label '{label_name}'", line)
            self.instructions[instr_idx].arg_val = self._labels[label_name]

        return self

    def _parse_directive(self, tokens, pos):
        tok = tokens[pos]
        name = tok.value
        pos += 1
        if name == '.func':
            fname_tok = tokens[pos]
            if fname_tok.type != 'IDENT':
                raise AsmError(".func expects a name", fname_tok.line)
            fname = fname_tok.value
            pos += 1
            arity_tok = tokens[pos]
            if arity_tok.type != 'INT':
                raise AsmError(".func expects an integer arity", arity_tok.line)
            arity = int(arity_tok.value)
            pos += 1
            if fname in self.functions or (self._pending_func and self._pending_func[0] == fname):
                raise AsmError(f"function '{fname}' declared more than once", tok.line)
            self._pending_func = (fname, arity)
            return self._expect_line_end(tokens, pos)
        raise AsmError(f"unknown directive '{name}'", tok.line)

    def _expect_line_end(self, tokens, pos):
        tok = tokens[pos]
        if tok.type not in ('NEWLINE', 'EOF'):
            raise AsmError(f"unexpected token after statement: {tok.type} ({tok.value!r})", tok.line)
        if tok.type == 'NEWLINE':
            pos += 1
        return pos

    def _parse_instruction(self, tokens, pos):
        mnem_tok = tokens[pos]
        mnem = mnem_tok.value.upper()
        if mnem not in OPCODES:
            raise AsmError(f"unknown instruction '{mnem_tok.value}'", mnem_tok.line)
        pos += 1

        arg_type, arg_val, extra = ARG_NONE, 0, 0
        tok = tokens[pos]
        if tok.type not in ('NEWLINE', 'EOF'):
            arg_type, arg_val, pos = self._parse_operand(tokens, pos, mnem)
            tok = tokens[pos]
            if tok.type == 'COMMA':
                pos += 1
                extra_tok = tokens[pos]
                if extra_tok.type != 'INT':
                    raise AsmError("expected an integer for the extra field", extra_tok.line)
                extra = int(extra_tok.value)
                pos += 1

        idx = len(self.instructions)
        self.instructions.append(Instr(OPCODES[mnem], arg_type, arg_val, extra, mnem_tok.line))

        if self._pending_func is not None:
            # A .func directive with no intervening label -- the function
            # entry is this instruction itself.
            fname, arity = self._pending_func
            self.functions[fname] = FuncMeta(fname, [None] * arity, idx)
            self.add_string(fname)
            self._pending_func = None

        return self._expect_line_end(tokens, pos)

    def _parse_operand(self, tokens, pos, mnem):
        tok = tokens[pos]
        if tok.type == 'STRING':
            return ARG_STR, self.add_string(tok.value), pos + 1
        if tok.type == 'FLOAT':
            # Stored the same way the compiler stores float literals: as
            # the string form of the float, referenced by string index.
            return ARG_STR, self.add_string(repr(float(tok.value))), pos + 1
        if tok.type == 'INT':
            return ARG_IMM, int(tok.value), pos + 1
        if tok.type == 'IDENT':
            # A bare identifier is a label reference, resolved once every
            # label in the file has been seen.
            idx = len(self.instructions)
            self._label_uses.append((idx, tok.value, tok.line))
            return ARG_IMM, 0, pos + 1
        raise AsmError(f"invalid operand for {mnem}: {tok.type} ({tok.value!r})", tok.line)

    def assemble(self):
        """Produce the same byte layout BinaryCompiler.assemble() does."""
        out = bytearray(b"CVM\x04")
        out.extend(struct.pack(">H", len(self.strings)))
        for s in self.strings:
            enc = s.encode('utf-8')
            out.extend(struct.pack(">H", len(enc)))
            out.extend(enc)
        out.extend(struct.pack(">I", len(self.instructions)))
        for ins in self.instructions:
            out.extend(struct.pack(">BBih", ins.op, ins.arg_type, ins.arg_val, ins.extra))
        out.extend(struct.pack(">H", len(self.functions)))
        for meta in self.functions.values():
            out.extend(struct.pack(">HIH", self._string_index[meta.name], meta.addr, len(meta.params)))
        runs = []
        for ins in self.instructions:
            line = ins.line if ins.line is not None else -1
            if runs and runs[-1][1] == line:
                runs[-1][0] += 1
            else:
                runs.append([1, line])
        out.extend(struct.pack(">I", len(runs)))
        for count, line in runs:
            out.extend(struct.pack(">Ii", count, line))
        return bytes(out)


def assemble_source(text):
    """Convenience: CRT assembly text -> assembled CVM bytecode bytes."""
    return Assembler().assemble_text(text).assemble()


# =====================================================================
# 4. CVM RUNTIME (bytecode -> execution)
# =====================================================================
#
# The runtime is a straightforward stack machine. A CVM module is:
#
#   header   : "CVM" + version byte (currently 0x04)
#   strings  : u16 count, then each string as (u16 length, utf-8 bytes)
#   code     : u32 instruction count, then each instruction as the fixed
#              8-byte record described at the top of this file
#              (>BBih -> opcode u8, arg_type u8, arg_val i32, extra i16)
#   funcs    : u16 count, then each as (u16 name string-index, u32 addr,
#              u16 param count) -- this is how CALL targets get resolved:
#              by name, not by guessing from call order (self-recursive
#              functions can be called before any outside caller reaches
#              them, so order alone can't be trusted), and the param
#              count lets the runtime reject wrong-arity calls cleanly
#              instead of failing with a raw stack underflow.
#
# Values at runtime are plain Python objects: int, float, bool, str, None,
# list, and dict (for CRT objects).


class CVMLoadError(CRTError):
    pass


class Frame:
    """One call frame: local variables plus the return address."""
    __slots__ = ("locals", "return_addr")

    def __init__(self, return_addr):
        self.locals = {}
        self.return_addr = return_addr


class CVMModule:
    """A parsed CVM binary: strings, instructions, and the function table
    (name -> (entry address, param count)) written by assemble()."""

    MAGIC = b"CVM"
    VERSION = 0x04

    def __init__(self, strings, instructions, functions):
        self.strings = strings
        self.instructions = instructions
        self.functions = functions  # name (str) -> (entry address, param count)


def load_module(data):
    """Parse raw CVM bytes into strings, instructions, and the function
    table. Layout (all integers big-endian):
        magic    : "CVM" + version byte
        strings  : u16 count, then each as (u16 length, utf-8 bytes)
        code     : u32 count, then each instruction as (u8 op, u8 arg_type,
                   i32 arg_val, i16 extra)
        funcs    : u16 count, then each as (u16 name string-index, u32 addr,
                   u16 param count)
        lines    : u32 run count, then each as (u32 run length, i32 line);
                   -1 means unknown. Runs cover instructions in order.
    """
    if len(data) < 4 or data[:3] != CVMModule.MAGIC:
        raise CVMLoadError("not a CVM file (bad magic)")
    version = data[3]
    if version != CVMModule.VERSION:
        raise CVMLoadError(f"unsupported CVM version {version} (expected {CVMModule.VERSION})")

    pos = 4
    (str_count,) = struct.unpack_from(">H", data, pos)
    pos += 2
    strings = []
    for _ in range(str_count):
        (slen,) = struct.unpack_from(">H", data, pos)
        pos += 2
        s = data[pos:pos + slen].decode('utf-8')
        pos += slen
        strings.append(s)

    (instr_count,) = struct.unpack_from(">I", data, pos)
    pos += 4
    instructions = []
    for _ in range(instr_count):
        op, arg_type, arg_val, extra = struct.unpack_from(">BBih", data, pos)
        pos += 8
        instructions.append(Instr(op, arg_type, arg_val, extra, None))

    functions = {}
    if pos + 2 <= len(data):
        (func_count,) = struct.unpack_from(">H", data, pos)
        pos += 2
        for _ in range(func_count):
            name_idx, addr, arity = struct.unpack_from(">HIH", data, pos)
            pos += 8
            functions[strings[name_idx]] = (addr, arity)

    if pos + 4 <= len(data):
        (run_count,) = struct.unpack_from(">I", data, pos)
        pos += 4
        idx = 0
        for _ in range(run_count):
            count, line = struct.unpack_from(">Ii", data, pos)
            pos += 8
            resolved = line if line != -1 else None
            for _ in range(count):
                if idx < len(instructions):
                    instructions[idx].line = resolved
                idx += 1

    return CVMModule(strings, instructions, functions)


class _PygameBackend:
    """Thin wrapper around pygame, created lazily the first time a script
    calls any pygame_* builtin. Import is deferred here (not at module load
    time) so `crt run` works fine on machines without pygame installed, as
    long as the script never actually enters graphics mode."""

    _KEY_NAMES = None  # populated on first use, once pygame is importable

    def __init__(self, err_fn):
        self._err = err_fn
        self._pygame = None
        self.screen = None
        self.clock = None
        self._font = None
        self._quit_requested = False
        self._mouse_clicked = False   # true for the frame a left-click happened
        self._images = {}       # handle (int) -> pygame Surface
        self._sounds = {}       # handle (int) -> pygame Sound
        self._next_handle = 1
        self._mixer_ready = False
        self.cameras = {}       # id (int) -> Camera3D
        self._next_camera_id = 1
        self.active_camera = None  # most recently created camera, used to
                                    # project 3D vertices in pygame_polygon
        self.objects = {}       # id (int) -> PygameObject
        self._next_object_id = 1

    def _ensure_pygame(self):
        if self._pygame is not None:
            return self._pygame
        try:
            import pygame
        except ImportError:
            self._err(
                "pygame is not installed. Install it with: pip install pygame"
            )
        self._pygame = pygame
        if _PygameBackend._KEY_NAMES is None:
            _PygameBackend._KEY_NAMES = {
                "left": pygame.K_LEFT, "right": pygame.K_RIGHT,
                "up": pygame.K_UP, "down": pygame.K_DOWN,
                "space": pygame.K_SPACE, "enter": pygame.K_RETURN,
                "return": pygame.K_RETURN, "escape": pygame.K_ESCAPE,
                "esc": pygame.K_ESCAPE, "shift": pygame.K_LSHIFT,
                "ctrl": pygame.K_LCTRL, "tab": pygame.K_TAB,
            }
            for c in "abcdefghijklmnopqrstuvwxyz":
                _PygameBackend._KEY_NAMES[c] = getattr(pygame, f"K_{c}")
            for d in "0123456789":
                _PygameBackend._KEY_NAMES[d] = getattr(pygame, f"K_{d}")
        return pygame

    def _require_screen(self, caller):
        if self.screen is None:
            self._err(f"{caller}(): call pygame_init() before using graphics")

    def init(self, width, height, title):
        pygame = self._ensure_pygame()
        if width <= 0 or height <= 0:
            self._err("pygame_init(): width and height must be positive")
        pygame.init()
        self.screen = pygame.display.set_mode((width, height))
        pygame.display.set_caption(title)
        self.clock = pygame.time.Clock()
        self._font = pygame.font.SysFont(None, 24)
        self._quit_requested = False

    def quit(self):
        if self._pygame is not None and self.screen is not None:
            self._pygame.quit()
        self.screen = None
        self._quit_requested = False
        self._mouse_clicked = False
        self._images.clear()
        self._sounds.clear()
        self._mixer_ready = False
        self.cameras.clear()
        self.active_camera = None
        self.objects.clear()

    def clear(self, color):
        self._require_screen("pygame_clear")
        self.screen.fill(color)

    def rect(self, x, y, w, h, color):
        self._require_screen("pygame_rect")
        self._pygame.draw.rect(self.screen, color, (x, y, w, h))

    def circle(self, x, y, radius, color):
        self._require_screen("pygame_circle")
        if radius < 0:
            self._err("pygame_circle(): radius must be non-negative")
        self._pygame.draw.circle(self.screen, color, (x, y), radius)

    def line(self, x1, y1, x2, y2, color):
        self._require_screen("pygame_line")
        self._pygame.draw.line(self.screen, color, (x1, y1), (x2, y2))

    def text(self, x, y, text, color):
        self._require_screen("pygame_text")
        surf = self._font.render(text, True, color)
        self.screen.blit(surf, (x, y))

    def flip(self):
        self._require_screen("pygame_flip")
        self._pygame.display.flip()

    def _pump_events(self):
        """Drain pygame's event queue once, updating quit/click flags. Safe
        to call from multiple places (poll_quit, mouse_clicked) since each
        just reads the flags this sets rather than draining the queue
        itself -- otherwise whichever one polled first would silently eat
        the other's events."""
        for event in self._pygame.event.get():
            if event.type == self._pygame.QUIT:
                self._quit_requested = True
            elif event.type == self._pygame.MOUSEBUTTONDOWN and event.button == 1:
                self._mouse_clicked = True

    def poll_quit(self):
        self._require_screen("pygame_poll_quit")
        self._pump_events()
        return self._quit_requested

    def mouse_pos(self):
        self._require_screen("pygame_mouse_x")
        return self._pygame.mouse.get_pos()

    def mouse_clicked(self):
        self._require_screen("pygame_mouse_clicked")
        self._pump_events()
        clicked = self._mouse_clicked
        self._mouse_clicked = False
        return clicked

    def _peek_click(self):
        """Like mouse_clicked() but doesn't consume the flag -- used by
        button hit-testing, which needs to check the click without
        stealing it from a script that also calls pygame_mouse_clicked()
        elsewhere. Buttons still only fire once per actual click: see
        button_clicked(), which does consume the flag once it determines
        the click landed inside that particular button."""
        self._pump_events()
        return self._mouse_clicked

    def key_down(self, key_name):
        self._require_screen("pygame_key")
        code = self._KEY_NAMES.get(key_name.lower())
        if code is None:
            self._err(f"pygame_key(): unknown key name '{key_name}'")
        pressed = self._pygame.key.get_pressed()
        return bool(pressed[code])

    def tick(self, fps):
        self._require_screen("pygame_tick")
        if fps <= 0:
            self._err("pygame_tick(): fps must be positive")
        return float(self.clock.tick(fps))

    # ---- textures (Pillow -> pygame surface) ---------------------------

    def load_image(self, path):
        self._require_screen("pygame_load_image")
        try:
            from PIL import Image
        except ImportError:
            self._err("Pillow is not installed. Install it with: pip install Pillow")
        try:
            img = Image.open(path).convert("RGBA")
        except FileNotFoundError:
            self._err(f"pygame_load_image(): no such file '{path}'")
        except Exception as e:
            self._err(f"pygame_load_image(): could not load '{path}' ({e})")
        surf = self._pygame.image.fromstring(img.tobytes(), img.size, "RGBA")
        handle = self._next_handle
        self._next_handle += 1
        self._images[handle] = surf
        return handle

    def draw_image(self, handle, x, y):
        self._require_screen("pygame_draw_image")
        surf = self._images.get(handle)
        if surf is None:
            self._err(f"pygame_draw_image(): invalid image handle {handle}")
        self.screen.blit(surf, (x, y))

    def image_size(self, handle):
        self._require_screen("pygame_image_size")
        surf = self._images.get(handle)
        if surf is None:
            self._err(f"pygame_image_size(): invalid image handle {handle}")
        w, h = surf.get_size()
        return w, h

    # ---- audio -----------------------------------------------------

    def _ensure_mixer(self, caller):
        self._require_screen(caller)
        if not self._mixer_ready:
            try:
                self._pygame.mixer.init()
                self._mixer_ready = True
            except self._pygame.error as e:
                self._err(f"{caller}(): could not initialize audio ({e})")

    def load_sound(self, path):
        self._ensure_mixer("pygame_load_sound")
        try:
            sound = self._pygame.mixer.Sound(path)
        except FileNotFoundError:
            self._err(f"pygame_load_sound(): no such file '{path}'")
        except self._pygame.error as e:
            self._err(f"pygame_load_sound(): could not load '{path}' ({e})")
        handle = self._next_handle
        self._next_handle += 1
        self._sounds[handle] = sound
        return handle

    def play_sound(self, handle):
        self._ensure_mixer("pygame_play_sound")
        sound = self._sounds.get(handle)
        if sound is None:
            self._err(f"pygame_play_sound(): invalid sound handle {handle}")
        sound.play()

    def stop_sound(self, handle):
        self._ensure_mixer("pygame_stop_sound")
        sound = self._sounds.get(handle)
        if sound is None:
            self._err(f"pygame_stop_sound(): invalid sound handle {handle}")
        sound.stop()

    def set_volume(self, handle, volume):
        self._ensure_mixer("pygame_set_volume")
        sound = self._sounds.get(handle)
        if sound is None:
            self._err(f"pygame_set_volume(): invalid sound handle {handle}")
        if volume < 0.0 or volume > 1.0:
            self._err("pygame_set_volume(): volume must be between 0.0 and 1.0")
        sound.set_volume(volume)

    # ---- 3D camera ---------------------------------------------------

    def new_camera(self):
        self._require_screen("pygame_camera")
        handle = self._next_camera_id
        self._next_camera_id += 1
        cam = Camera3D()
        self.cameras[handle] = cam
        self.active_camera = cam
        return handle

    def get_camera(self, handle, caller):
        cam = self.cameras.get(handle)
        if cam is None:
            self._err(f"{caller}(): invalid camera")
        return cam

    def project_vertex(self, v3, caller):
        """v3: (x, y, z) world point. Uses the most recently created
        camera; a clear error if a 3D vertex is used with no camera yet
        (there's nothing sensible to project it with)."""
        if self.active_camera is None:
            self._err(f"{caller}(): a 3D vertex needs a camera -- call "
                       f"pygame_camera() first")
        w, h = self.screen.get_size()
        result = self.active_camera.project(v3[0], v3[1], v3[2], w, h)
        if result is None:
            return None
        sx, sy, _depth = result
        return sx, sy

    # ---- simple objects (pygame_object) -----------------------------

    def new_object(self):
        self._require_screen("pygame_object")
        handle = self._next_object_id
        self._next_object_id += 1
        self.objects[handle] = PygameObject()
        return handle

    def get_object(self, handle, caller):
        obj = self.objects.get(handle)
        if obj is None:
            self._err(f"{caller}(): invalid object")
        return obj

    def _object_screen_rect(self, obj, caller):
        """Returns the object's current on-screen (x, y, w, h) rect, or
        None if it's a 3D object whose position is currently behind the
        camera (nothing to draw or click this frame)."""
        if obj.is_3d:
            proj = self.project_vertex((obj.x, obj.y, obj.z), caller)
            if proj is None:
                return None
            cx, cy = proj
        else:
            cx, cy = obj.x, obj.y
        # Position is the shape's center, matching how pygame_circle and
        # pygame_vertex-based polygons are already centered on their
        # given point rather than anchored at a corner.
        return (cx - obj.w / 2, cy - obj.h / 2, obj.w, obj.h)

    def object_rectangle(self, handle, w, h, color):
        obj = self.get_object(handle, "pygame_object.rectangle")
        if w < 0 or h < 0:
            self._err("object.rectangle(): width and height must be non-negative")
        obj.shape = "rectangle"
        obj.w, obj.h = w, h
        obj.color = color

    def object_draw(self, handle):
        obj = self.get_object(handle, "pygame_object.draw")
        self._require_screen("pygame_object.draw")
        if obj.shape is None:
            self._err("object.draw(): give it a shape first, e.g. .rectangle(w, h, r, g, b)")
        rect = self._object_screen_rect(obj, "pygame_object.draw")
        if rect is None:
            return  # 3D object currently behind the camera: nothing to draw
        self._pygame.draw.rect(self.screen, obj.color, rect)

    def object_clicked(self, handle):
        obj = self.get_object(handle, "pygame_object.clicked")
        self._require_screen("pygame_object.clicked")
        if obj.shape is None:
            self._err("object.clicked(): give it a shape first, e.g. .rectangle(w, h, r, g, b)")
        click_pending = self._peek_click()
        mx, my = self._pygame.mouse.get_pos()
        rect = self._object_screen_rect(obj, "pygame_object.clicked")
        inside = rect is not None and rect[0] <= mx <= rect[0] + rect[2] and rect[1] <= my <= rect[1] + rect[3]
        # Edge-triggered on this object's own state, not the shared
        # _mouse_clicked flag -- so several objects can each correctly
        # detect (or not detect) the same physical click independently.
        fired = click_pending and inside and not obj._was_down
        obj._was_down = click_pending and inside
        return fired

    # ---- 2D/3D polygons --------------------------------------------

    def polygon(self, points, color):
        """points: list of (x, y) pixel pairs, already projected if they
        started out as 3D. Needs at least 3 points to be a real polygon."""
        self._require_screen("pygame_polygon")
        if len(points) < 3:
            self._err("pygame_polygon(): needs at least 3 vertices")
        self._pygame.draw.polygon(self.screen, color, points)

    def polygon_texture(self, points, handle, uvs):
        """Fills a (2D or projected-3D) polygon with a texture, sampled
        via the given per-vertex UVs (0..1 across the source image).
        Triangulates as a fan from vertex 0 and affine-warps each source
        triangle onto its projected destination triangle -- the same
        approach simple software 3D renderers use for texture mapping,
        good enough for flat, reasonably-sized polygons without a full
        perspective-correct rasterizer."""
        self._require_screen("pygame_polygon_texture")
        if len(points) < 3:
            self._err("pygame_polygon_texture(): needs at least 3 vertices")
        surf = self._images.get(handle)
        if surf is None:
            self._err(f"pygame_polygon_texture(): invalid image handle {handle}")
        if len(uvs) != len(points):
            self._err("pygame_polygon_texture(): needs one uv per vertex")
        iw, ih = surf.get_size()
        src_pts = [(u * iw, v * ih) for (u, v) in uvs]
        for i in range(1, len(points) - 1):
            self._draw_textured_triangle(
                surf,
                (src_pts[0], src_pts[i], src_pts[i + 1]),
                (points[0], points[i], points[i + 1]),
            )

    def _draw_textured_triangle(self, surf, src_tri, dst_tri):
        pygame = self._pygame
        (sx0, sy0), (sx1, sy1), (sx2, sy2) = src_tri
        (dx0, dy0), (dx1, dy1), (dx2, dy2) = dst_tri

        # Degenerate destination triangle (zero area, e.g. an edge-on 3D
        # face) -- nothing useful to draw, and the affine solve below
        # would divide by zero.
        area = (dx1 - dx0) * (dy2 - dy0) - (dx2 - dx0) * (dy1 - dy0)
        if abs(area) < 1e-6:
            return

        # Crop to the source triangle's bounding box so we only warp the
        # relevant slice of the texture, not the whole image every time.
        min_sx = max(int(min(sx0, sx1, sx2)), 0)
        min_sy = max(int(min(sy0, sy1, sy2)), 0)
        max_sx = min(int(max(sx0, sx1, sx2)) + 1, surf.get_width())
        max_sy = min(int(max(sy0, sy1, sy2)) + 1, surf.get_height())
        if max_sx <= min_sx or max_sy <= min_sy:
            return
        crop_rect = pygame.Rect(min_sx, min_sy, max_sx - min_sx, max_sy - min_sy)
        cropped = surf.subsurface(crop_rect)

        src_local = [(sx0 - min_sx, sy0 - min_sy), (sx1 - min_sx, sy1 - min_sy),
                     (sx2 - min_sx, sy2 - min_sy)]

        # Solve the 2x3 affine map src_local -> dst that carries the
        # texture's triangle onto the projected screen triangle, then let
        # pygame.transform do the actual per-pixel warp.
        matrix, ok = self._affine_from_triangles(src_local, dst_tri)
        if not ok:
            return
        try:
            warped = pygame.transform.affine_transform(cropped, matrix)
        except AttributeError:
            # Older pygame without affine_transform: fall back to a flat
            # average-color fill so texture calls still degrade gracefully.
            avg = pygame.transform.average_color(cropped)[:3]
            pygame.draw.polygon(self.screen, avg, dst_tri)
            return

        # affine_transform maps around the *source* surface's own origin,
        # so figure out where (0,0) of `cropped` landed in dst-space and
        # blit the warped result there, clipped to the destination
        # triangle so it doesn't spill outside as a rectangle.
        ox, oy = self._affine_apply(matrix, (0, 0))
        clip = pygame.Surface(warped.get_size(), pygame.SRCALPHA)
        clip.blit(warped, (0, 0))
        mask_surf = pygame.Surface(warped.get_size(), pygame.SRCALPHA)
        local_tri = [(dx0 - ox, dy0 - oy), (dx1 - ox, dy1 - oy), (dx2 - ox, dy2 - oy)]
        pygame.draw.polygon(mask_surf, (255, 255, 255, 255), local_tri)
        clip.blit(mask_surf, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
        self.screen.blit(clip, (ox, oy))

    @staticmethod
    def _affine_from_triangles(src, dst):
        """Returns (matrix, ok). matrix is the 6-tuple pygame.transform.
        affine_transform expects; ok is False if the source triangle is
        degenerate (zero area) and no sensible map exists."""
        (x0, y0), (x1, y1), (x2, y2) = src
        (u0, v0), (u1, v1), (u2, v2) = dst
        denom = (x1 - x0) * (y2 - y0) - (x2 - x0) * (y1 - y0)
        if abs(denom) < 1e-9:
            return None, False
        a = ((u1 - u0) * (y2 - y0) - (u2 - u0) * (y1 - y0)) / denom
        b = ((u2 - u0) * (x1 - x0) - (u1 - u0) * (x2 - x0)) / denom
        c = u0 - a * x0 - b * y0
        d = ((v1 - v0) * (y2 - y0) - (v2 - v0) * (y1 - y0)) / denom
        e = ((v2 - v0) * (x1 - x0) - (v1 - v0) * (x2 - x0)) / denom
        f = v0 - d * x0 - e * y0
        return (a, b, c, d, e, f), True

    @staticmethod
    def _affine_apply(matrix, pt):
        a, b, c, d, e, f = matrix
        x, y = pt
        return (a * x + b * y + c, d * x + e * y + f)


class Camera3D:
    """Runtime state for a pygame_camera() native object. Plain position +
    yaw/pitch angles (degrees) + field of view -- enough to project 3D
    vertices to screen pixels for pygame_polygon / pygame_polygon_texture,
    without pulling in a matrix/vector math dependency."""

    def __init__(self):
        self.x = 0.0
        self.y = 0.0
        self.z = 0.0
        self.yaw = 0.0     # degrees, turning left/right around the y axis
        self.pitch = 0.0   # degrees, tilting up/down
        self.fov = 70.0    # degrees, vertical field of view

    def project(self, wx, wy, wz, screen_w, screen_h):
        """World-space (x, y, z) -> (screen_x, screen_y, depth) or None if
        the point is behind the camera (can't be projected). depth is the
        camera-space distance along the view axis, useful for sorting."""
        # Translate into camera-relative space.
        dx, dy, dz = wx - self.x, wy - self.y, wz - self.z

        # Rotate by -yaw around Y, then -pitch around X, so "forward" in
        # camera space is always +z regardless of which way the camera
        # is looking.
        yaw = math.radians(-self.yaw)
        cy, sy = math.cos(yaw), math.sin(yaw)
        rx = dx * cy + dz * sy
        rz = -dx * sy + dz * cy

        pitch = math.radians(-self.pitch)
        cp, sp = math.cos(pitch), math.sin(pitch)
        ry = dy * cp - rz * sp
        cz = dy * sp + rz * cp

        if cz <= 0.01:
            return None  # behind (or right on top of) the camera

        fov_rad = math.radians(self.fov)
        f = 1.0 / math.tan(fov_rad / 2.0)
        aspect = screen_w / screen_h if screen_h else 1.0

        ndc_x = (rx * f / aspect) / cz
        ndc_y = (ry * f) / cz

        sx = (ndc_x * 0.5 + 0.5) * screen_w
        sy = (1.0 - (ndc_y * 0.5 + 0.5)) * screen_h
        return sx, sy, cz

    def forward_vec(self):
        """The world-space direction the camera is currently facing, as a
        plain (dx, dy, dz) tuple -- the inverse of the rotation `project`
        applies, evaluated at zero pitch/yaw offset (i.e. where local +z
        ends up after yaw and pitch are applied)."""
        yaw = math.radians(self.yaw)
        pitch = math.radians(self.pitch)
        # Same rotation as project(), applied forward instead of inverse:
        # start facing +z, tilt by pitch, then turn by yaw.
        fx = math.sin(yaw) * math.cos(pitch)
        fy = math.sin(pitch)
        fz = math.cos(yaw) * math.cos(pitch)
        return fx, fy, fz

    def look_at(self, tx, ty, tz):
        """Points the camera at a world position by setting yaw/pitch to
        match, without moving it."""
        dx, dy, dz = tx - self.x, ty - self.y, tz - self.z
        dist_xz = math.sqrt(dx * dx + dz * dz)
        self.yaw = math.degrees(math.atan2(dx, dz))
        self.pitch = math.degrees(math.atan2(dy, dist_xz)) if dist_xz > 1e-9 else (90.0 if dy > 0 else -90.0)

    def orbit(self, tx, ty, tz, distance):
        """Moves the camera to `distance` away from (tx,ty,tz), back along
        its current facing direction, then re-aims it at the target. A
        typical use is: cam.rotate(angle, 0) then cam.orbit(target, 6)
        each frame, to swing the camera around a fixed point."""
        fx, fy, fz = self.forward_vec()
        self.x = tx - fx * distance
        self.y = ty - fy * distance
        self.z = tz - fz * distance
        self.look_at(tx, ty, tz)


class PygameObject:
    """Runtime state for a pygame_object() native object: a simple
    positionable, clickable, drawable on-screen thing. Currently the only
    shape is a rectangle (set via .rectangle()); position can be 2D
    (screen pixels) or 3D (world space, projected through the active
    camera at draw time, same as pygame_vertex3)."""

    def __init__(self):
        self.shape = None       # None until .rectangle() is called
        self.w = 0.0
        self.h = 0.0
        self.color = (255, 255, 255)
        self.is_3d = False
        self.x = 0.0
        self.y = 0.0
        self.z = 0.0
        self._was_down = False  # edge-tracking for .clicked(), independent
                                 # of pygame_mouse_clicked()'s own flag

    def set_pos2(self, x, y):
        self.is_3d = False
        self.x, self.y = x, y

    def set_pos3(self, x, y, z):
        self.is_3d = True
        self.x, self.y, self.z = x, y, z

    def get_pos_vec(self):
        if self.is_3d:
            return make_vec(self.x, self.y, self.z)
        return make_vec(self.x, self.y)


class CVM:
    """Executes a loaded CVM module."""

    def __init__(self, module, out=None):
        self.module = module
        self.instructions = module.instructions
        self.strings = module.strings
        self.out = out if out is not None else sys.stdout

        self.stack = []
        self.globals = {}
        self.frames = []  # call stack of Frame objects; [] means top-level scope
        self._pending_return_addr = None  # set by CALL just before jumping; consumed by MAKE_FRAME
        self.pc = 0

        self.func_table = module.functions
        self.gfx = None  # lazily-created _PygameBackend, only if a pygame_* builtin is actually called
        self._py_modules = {}   # top-level name -> imported Python module,
                                 # populated by py_import; see run()
        self._py_objects = {}   # handle (int) -> opaque Python value that
                                 # run() couldn't convert to a CRT value
                                 # (so it can still be passed into a later
                                 # run() call instead of being lost)
        self._next_py_handle = 1

    # ---- helpers -----------------------------------------------------

    def _err(self, msg):
        line = self.instructions[self.pc].line if self.pc < len(self.instructions) else None
        raise CRTRuntimeError(msg, line)

    def _pop(self):
        if not self.stack:
            self._err("stack underflow")
        return self.stack.pop()

    def _push(self, v):
        self.stack.append(v)

    def _current_scope(self):
        return self.frames[-1].locals if self.frames else self.globals

    def _load(self, name):
        if self.frames and name in self.frames[-1].locals:
            return self.frames[-1].locals[name]
        if name in self.globals:
            return self.globals[name]
        self._err(f"undefined variable '{name}'")

    def _store(self, name, val):
        # Plain assignment (x = ...): write through to wherever the name
        # is already bound -- local first, then global -- so mutating a
        # variable from inside a function updates the outer binding
        # instead of silently shadowing it with a new local. Only creates
        # a new binding (in the current scope) if the name isn't bound
        # anywhere yet.
        if self.frames and name in self.frames[-1].locals:
            self.frames[-1].locals[name] = val
        elif name in self.globals:
            self.globals[name] = val
        else:
            self._current_scope()[name] = val

    def _store_local(self, name, val):
        # Declaration / parameter binding (let x = ..., or a function
        # parameter): always creates/overwrites in the current scope,
        # even if a variable with the same name exists further out.
        self._current_scope()[name] = val

    @staticmethod
    def _truthy(v):
        if v is None:
            return False
        if isinstance(v, bool):
            return v
        if isinstance(v, (int, float)):
            return v != 0
        if isinstance(v, str):
            return len(v) > 0
        if isinstance(v, (list, dict)):
            return len(v) > 0
        return True

    @staticmethod
    def _type_name(v):
        if v is None:
            return "null"
        if isinstance(v, bool):
            return "bool"
        if isinstance(v, int):
            return "int"
        if isinstance(v, float):
            return "float"
        if isinstance(v, str):
            return "string"
        if isinstance(v, list):
            return "list"
        if isinstance(v, dict):
            if "__vec__" in v:
                return f"vec{v['__vec__']}"
            if "__mat__" in v:
                return f"mat{v['__mat__']}"
            if "__native__" in v:
                return v["__native__"]
            return "object"
        return "unknown"

    def _as_number(self, v, fn_name):
        if isinstance(v, bool) or not isinstance(v, (int, float)):
            self._err(f"{fn_name}() requires a number, got {self._type_name(v)}")
        return v

    def _as_vec(self, v, fn_name, want=None):
        if not isinstance(v, dict) or "__vec__" not in v:
            self._err(f"{fn_name}() requires a vector, got {self._type_name(v)}")
        if want is not None and v["__vec__"] != want:
            self._err(f"{fn_name}() requires a vec{want}, got vec{v['__vec__']}")
        return v

    def _vec_op(self, fn, a, b, fn_name):
        if a["__vec__"] != b["__vec__"]:
            self._err(f"{fn_name}(): vectors must be the same size (vec{a['__vec__']} vs vec{b['__vec__']})")
        return fn(a, b)

    def _as_transform(self, v, fn_name):
        if not isinstance(v, dict) or "pos" not in v or "rot" not in v or "scale" not in v:
            self._err(f"{fn_name}() requires a transform() object")
        return v

    def _as_aabb(self, v, fn_name):
        if not isinstance(v, dict) or "__aabb__" not in v:
            self._err(f"{fn_name}() requires an aabb() object")
        return v

    def _as_sphere(self, v, fn_name):
        if not isinstance(v, dict) or "__sphere__" not in v:
            self._err(f"{fn_name}() requires a sphere() object")
        return v

    @staticmethod
    def _ray_aabb(origin, direction, box):
        """Standard slab method: for each axis, find the interval of t
        where the ray is inside the box's slab, then intersect all three
        intervals. A hit exists if what's left is non-empty and doesn't
        end behind the ray's origin."""
        tmin, tmax = -math.inf, math.inf
        for ax in "xyz":
            o, d = origin[ax], direction[ax]
            lo, hi = box["min"][ax], box["max"][ax]
            if abs(d) < 1e-12:
                if o < lo or o > hi:
                    return False
                continue
            t1, t2 = (lo - o) / d, (hi - o) / d
            if t1 > t2:
                t1, t2 = t2, t1
            tmin, tmax = max(tmin, t1), min(tmax, t2)
            if tmin > tmax:
                return False
        return tmax >= 0

    def _to_display(self, v):
        if v is None:
            return "null"
        if isinstance(v, bool):
            return "true" if v else "false"
        if isinstance(v, list):
            return "[" + ", ".join(self._to_display(x) for x in v) + "]"
        if isinstance(v, dict):
            if "__vec__" in v:
                n = v["__vec__"]
                comps = ", ".join(self._to_display(c) for c in vec_components(v, n))
                return f"vec{n}({comps})"
            if "__mat__" in v:
                rows = [", ".join(self._to_display(x) for x in v["m"][r * 4:(r + 1) * 4]) for r in range(4)]
                return "mat4(" + " | ".join(rows) + ")"
            return "{" + ", ".join(f"{k}: {self._to_display(x)}" for k, x in v.items()) + "}"
        if isinstance(v, float):
            if v == int(v) and abs(v) < 1e16:
                return f"{v:.1f}"
            return repr(v)
        return str(v)

    # ---- arithmetic / comparisons --------------------------------------

    def _arith(self, op):
        b = self._pop()
        a = self._pop()
        try:
            is_vec_a, is_vec_b = isinstance(a, dict) and "__vec__" in a, isinstance(b, dict) and "__vec__" in b
            is_mat_a, is_mat_b = isinstance(a, dict) and "__mat__" in a, isinstance(b, dict) and "__mat__" in b
            if is_vec_a or is_vec_b or is_mat_a or is_mat_b:
                self._push(self._vec_mat_arith(op, a, b, is_vec_a, is_vec_b, is_mat_a, is_mat_b))
            elif op == "ADD":
                if isinstance(a, str) or isinstance(b, str):
                    self._push(self._to_display(a) + self._to_display(b) if not (isinstance(a, str) and isinstance(b, str)) else a + b)
                elif isinstance(a, list) and isinstance(b, list):
                    self._push(a + b)
                else:
                    self._push(a + b)
            elif op == "SUB":
                self._push(a - b)
            elif op == "MUL":
                self._push(a * b)
            elif op == "DIV":
                if b == 0:
                    self._err("division by zero")
                if isinstance(a, int) and isinstance(b, int) and a % b == 0:
                    self._push(a // b)
                else:
                    self._push(a / b)
            elif op == "MOD":
                if b == 0:
                    self._err("modulo by zero")
                self._push(a % b)
        except TypeError:
            self._err(f"unsupported operand types for {op}: {self._type_name(a)} and {self._type_name(b)}")

    def _vec_mat_arith(self, op, a, b, is_vec_a, is_vec_b, is_mat_a, is_mat_b):
        """+/-/* between any mix of vec2/vec3/vec4, mat4, and plain
        numbers. Raises TypeError (caught by _arith, which turns it into
        a normal runtime error) for combinations that don't make sense,
        e.g. adding a vec3 to a vec2, or a matrix to a number."""
        is_num_a = isinstance(a, (int, float)) and not isinstance(a, bool)
        is_num_b = isinstance(b, (int, float)) and not isinstance(b, bool)

        if op == "ADD":
            if is_vec_a and is_vec_b:
                return vec_add(a, b)
        elif op == "SUB":
            if is_vec_a and is_vec_b:
                return vec_sub(a, b)
        elif op == "MUL":
            if is_vec_a and is_num_b:
                return vec_scale(a, b)
            if is_num_a and is_vec_b:
                return vec_scale(b, a)
            if is_mat_a and is_mat_b:
                return mat4_mul(a, b)
            if is_mat_a and is_vec_b:
                return mat4_mul_vec(a, b)
        raise TypeError("bad vector/matrix operand combination")

    def _compare(self, op):
        b = self._pop()
        a = self._pop()
        if op == "EQ":
            self._push(a == b)
        elif op == "NEQ":
            self._push(a != b)
        else:
            try:
                if op == "LT":
                    self._push(a < b)
                elif op == "GT":
                    self._push(a > b)
                elif op == "LTE":
                    self._push(a <= b)
                elif op == "GTE":
                    self._push(a >= b)
            except TypeError:
                self._err(f"cannot compare {self._type_name(a)} and {self._type_name(b)}")

    # ---- Python interop (py_import / run) ------------------------------

    def _py_import(self, module_path):
        """Runtime handler for the PY_IMPORT opcode. Imports a real Python
        module and stashes it under its top-level name (the part before
        the first dot) so run("name.rest.of.path", ...) can find it --
        e.g. py_import os.path imports Python's os.path submodule (which,
        as a side effect, makes it reachable as an attribute of os) and
        stores the top-level os module under the name "os", matching
        Python's own `import os.path` semantics (which binds the name
        `os`, with `.path` reachable off of it)."""
        try:
            importlib.import_module(module_path)
        except ImportError as e:
            self._err(f"py_import {module_path}: could not import it ({e})")
        top_name = module_path.split(".")[0]
        self._py_modules[top_name] = importlib.import_module(top_name)

    def _crt_to_py(self, v):
        """Converts a CRT value into a plain Python value to pass as an
        argument to a Python function via run(). Vectors become tuples
        (the natural shape for most Python APIs expecting x/y/z-ish
        arguments); an opaque handle unwraps back to the real object it
        was wrapping, so a value returned by one run() call can be fed
        into another."""
        if isinstance(v, dict):
            if "__pyobj__" in v:
                handle = v["__pyobj__"]
                if handle not in self._py_objects:
                    self._err(f"run(): stale or invalid Python object handle {handle}")
                return self._py_objects[handle]
            if "__vec__" in v:
                return tuple(vec_components(v, v["__vec__"]))
            if "__mat__" in v:
                return list(v["m"])
            return {k: self._crt_to_py(x) for k, x in v.items()}
        if isinstance(v, list):
            return [self._crt_to_py(x) for x in v]
        return v  # int, float, bool, str, None all pass through unchanged

    def _py_to_crt(self, v):
        """Converts a Python value coming back from run() into a CRT
        value. Primitives and plain lists/dicts convert directly;
        anything else (a file handle, a custom class instance, a numpy
        array, ...) becomes an opaque handle a script can still hold onto
        and pass into a later run() call, print, or compare, even though
        it can't look inside it."""
        if v is None or isinstance(v, (bool, int, float, str)):
            return v
        if isinstance(v, (list, tuple)):
            return [self._py_to_crt(x) for x in v]
        if isinstance(v, dict) and all(isinstance(k, str) for k in v):
            return {k: self._py_to_crt(x) for k, x in v.items()}
        handle = self._next_py_handle
        self._next_py_handle += 1
        self._py_objects[handle] = v
        return {"__pyobj__": handle, "__pyobj_repr__": repr(v)}

    def _resolve_py_path(self, dotted_path, caller):
        """Looks up "module.attr.attr..." against the modules py_import
        has brought in, walking the rest of the path with getattr. The
        first segment must be a name that was actually py_import'd --
        this is what stops run() from reaching arbitrary unimported
        modules through, say, a re-export."""
        parts = dotted_path.split(".")
        if len(parts) < 2:
            self._err(f"{caller}(): expected a dotted path like 'module.function', got '{dotted_path}'")
        top_name = parts[0]
        if top_name not in self._py_modules:
            self._err(f"{caller}(): '{top_name}' hasn't been py_import'd yet")
        obj = self._py_modules[top_name]
        for attr in parts[1:]:
            try:
                obj = getattr(obj, attr)
            except AttributeError:
                self._err(f"{caller}(): '{dotted_path}' -- no attribute '{attr}'")
        return obj

    # ---- builtins -----------------------------------------------------

    def _call_builtin(self, name, argc):
        args = [self._pop() for _ in range(argc)][::-1]

        def need(n):
            if len(args) != n:
                self._err(f"{name}() takes {n} argument(s), got {len(args)}")

        if name == "len":
            need(1)
            v = args[0]
            if isinstance(v, (str, list, dict)):
                self._push(len(v))
            else:
                self._err(f"len() not supported for type {self._type_name(v)}")
        elif name == "str":
            need(1)
            self._push(self._to_display(args[0]))
        elif name == "int":
            need(1)
            v = args[0]
            try:
                if isinstance(v, str):
                    self._push(int(v.strip()))
                elif isinstance(v, bool):
                    self._push(1 if v else 0)
                else:
                    self._push(int(v))
            except (ValueError, TypeError):
                self._err(f"cannot convert {self._type_name(v)} to int")
        elif name == "float":
            need(1)
            v = args[0]
            try:
                self._push(float(v))
            except (ValueError, TypeError):
                self._err(f"cannot convert {self._type_name(v)} to float")
        elif name == "type":
            need(1)
            self._push(self._type_name(args[0]))
        elif name == "upper":
            need(1)
            if not isinstance(args[0], str):
                self._err("upper() requires a string")
            self._push(args[0].upper())
        elif name == "lower":
            need(1)
            if not isinstance(args[0], str):
                self._err("lower() requires a string")
            self._push(args[0].lower())
        elif name == "json_encode":
            need(1)
            try:
                self._push(json.dumps(args[0]))
            except TypeError as e:
                self._err(f"json_encode(): cannot encode value ({e})")
        elif name == "json_decode":
            need(1)
            if not isinstance(args[0], str):
                self._err("json_decode() requires a string")
            try:
                self._push(json.loads(args[0]))
            except json.JSONDecodeError as e:
                self._err(f"json_decode(): invalid JSON ({e})")
        elif name == "file_read":
            need(1)
            if not isinstance(args[0], str):
                self._err("file_read() requires a string path")
            try:
                with open(args[0], "r", encoding="utf-8") as f:
                    self._push(f.read())
            except FileNotFoundError:
                self._err(f"file_read(): no such file '{args[0]}'")
            except OSError as e:
                self._err(f"file_read(): {e}")
        elif name == "file_write":
            need(2)
            path, content = args
            if not isinstance(path, str):
                self._err("file_write() requires a string path")
            if not isinstance(content, str):
                content = self._to_display(content)
            try:
                with open(path, "w", encoding="utf-8") as f:
                    f.write(content)
                self._push(None)
            except OSError as e:
                self._err(f"file_write(): {e}")
        elif name == "file_append":
            need(2)
            path, content = args
            if not isinstance(path, str):
                self._err("file_append() requires a string path")
            if not isinstance(content, str):
                content = self._to_display(content)
            try:
                with open(path, "a", encoding="utf-8") as f:
                    f.write(content)
                self._push(None)
            except OSError as e:
                self._err(f"file_append(): {e}")
        elif name == "file_exists":
            need(1)
            if not isinstance(args[0], str):
                self._err("file_exists() requires a string path")
            self._push(os.path.isfile(args[0]))
        elif name == "file_delete":
            need(1)
            if not isinstance(args[0], str):
                self._err("file_delete() requires a string path")
            try:
                os.remove(args[0])
                self._push(None)
            except FileNotFoundError:
                self._err(f"file_delete(): no such file '{args[0]}'")
            except OSError as e:
                self._err(f"file_delete(): {e}")
        elif name in ("pi", "e", "tau"):
            need(0)
            self._push({"pi": math.pi, "e": math.e, "tau": math.tau}[name])
        elif name in _MATH_UNARY:
            need(1)
            x = self._as_number(args[0], name)
            try:
                self._push(float(_MATH_UNARY[name](x)))
            except ValueError:
                self._err(f"{name}({x}) is not defined (domain error)")
        elif name == "atan2":
            need(2)
            y = self._as_number(args[0], name)
            x = self._as_number(args[1], name)
            self._push(float(math.atan2(y, x)))
        elif name == "pow":
            need(2)
            base = self._as_number(args[0], name)
            exp = self._as_number(args[1], name)
            try:
                self._push(float(math.pow(base, exp)))
            except ValueError:
                self._err(f"pow({base}, {exp}) is not defined (domain error)")
        elif name == "log":
            if len(args) not in (1, 2):
                self._err(f"log() takes 1 or 2 argument(s), got {len(args)}")
            x = self._as_number(args[0], name)
            try:
                if len(args) == 2:
                    base = self._as_number(args[1], name)
                    self._push(float(math.log(x, base)))
                else:
                    self._push(float(math.log(x)))
            except ValueError:
                self._err(f"log({x}) is not defined (domain error)")
        elif name == "floor":
            need(1)
            x = self._as_number(args[0], name)
            self._push(math.floor(x))
        elif name == "ceil":
            need(1)
            x = self._as_number(args[0], name)
            self._push(math.ceil(x))
        elif name == "round":
            if len(args) not in (1, 2):
                self._err(f"round() takes 1 or 2 argument(s), got {len(args)}")
            x = self._as_number(args[0], name)
            if len(args) == 2:
                ndigits = self._as_number(args[1], name)
                self._push(round(x, int(ndigits)))
            else:
                self._push(round(x))
        elif name == "abs":
            need(1)
            x = self._as_number(args[0], name)
            self._push(abs(x))
        elif name == "deg":
            need(1)
            x = self._as_number(args[0], name)
            self._push(float(math.degrees(x)))
        elif name == "rad":
            need(1)
            x = self._as_number(args[0], name)
            self._push(float(math.radians(x)))
        elif name == "vec2":
            need(2)
            self._push(make_vec(self._as_number(args[0], name), self._as_number(args[1], name)))
        elif name == "vec3":
            need(3)
            self._push(make_vec(*(self._as_number(a, name) for a in args)))
        elif name == "vec4":
            need(4)
            self._push(make_vec(*(self._as_number(a, name) for a in args)))
        elif name == "vec_dot":
            need(2)
            a, b = self._as_vec(args[0], name), self._as_vec(args[1], name)
            self._push(float(self._vec_op(vec_dot, a, b, name)))
        elif name == "vec_cross":
            need(2)
            a, b = self._as_vec(args[0], name, want=3), self._as_vec(args[1], name, want=3)
            self._push(vec3_cross(a, b))
        elif name == "vec_length":
            need(1)
            v = self._as_vec(args[0], name)
            self._push(float(vec_length(v)))
        elif name == "vec_normalize":
            need(1)
            v = self._as_vec(args[0], name)
            try:
                self._push(vec_normalize(v))
            except ValueError as e:
                self._err(f"{name}(): {e}")
        elif name == "vec_lerp":
            need(3)
            a, b = self._as_vec(args[0], name), self._as_vec(args[1], name)
            t = self._as_number(args[2], name)
            self._push(self._vec_op(lambda x, y: vec_lerp(x, y, t), a, b, name))
        elif name == "mat4_identity":
            need(0)
            self._push(mat4_identity())
        elif name == "mat4_translation":
            need(3)
            self._push(mat4_translation(*(self._as_number(a, name) for a in args)))
        elif name == "mat4_scale":
            need(3)
            self._push(mat4_scale(*(self._as_number(a, name) for a in args)))
        elif name == "mat4_rotate_x":
            need(1)
            self._push(mat4_rotation_x(self._as_number(args[0], name)))
        elif name == "mat4_rotate_y":
            need(1)
            self._push(mat4_rotation_y(self._as_number(args[0], name)))
        elif name == "mat4_rotate_z":
            need(1)
            self._push(mat4_rotation_z(self._as_number(args[0], name)))
        elif name == "transform":
            if len(args) == 0:
                pos, rot, scale = make_vec(0, 0, 0), make_vec(0, 0, 0), make_vec(1, 1, 1)
            elif len(args) == 3:
                pos = self._as_vec(args[0], name, want=3)
                rot = self._as_vec(args[1], name, want=3)
                scale = self._as_vec(args[2], name, want=3)
            else:
                self._err(f"{name}() takes 0 or 3 argument(s), got {len(args)}")
            self._push({"pos": pos, "rot": rot, "scale": scale})
        elif name == "transform_matrix":
            need(1)
            t = self._as_transform(args[0], name)
            m = mat4_mul(mat4_translation(*vec_components(t["pos"], 3)),
                          mat4_mul(mat4_rotation_y(t["rot"]["y"]),
                          mat4_mul(mat4_rotation_x(t["rot"]["x"]),
                          mat4_mul(mat4_rotation_z(t["rot"]["z"]),
                                    mat4_scale(*vec_components(t["scale"], 3))))))
            self._push(m)
        elif name == "transform_forward":
            need(1)
            t = self._as_transform(args[0], name)
            m = mat4_mul(mat4_rotation_y(t["rot"]["y"]), mat4_rotation_x(t["rot"]["x"]))
            self._push(mat4_mul_vec(m, make_vec(0, 0, 1)))
        elif name == "aabb":
            need(2)
            self._push({"__aabb__": True,
                        "min": self._as_vec(args[0], name, want=3),
                        "max": self._as_vec(args[1], name, want=3)})
        elif name == "sphere":
            need(2)
            self._push({"__sphere__": True,
                        "center": self._as_vec(args[0], name, want=3),
                        "radius": float(self._as_number(args[1], name))})
        elif name == "aabb_intersects":
            need(2)
            a = self._as_aabb(args[0], name)
            b = self._as_aabb(args[1], name)
            hit = all(a["min"][ax] <= b["max"][ax] and a["max"][ax] >= b["min"][ax] for ax in "xyz")
            self._push(hit)
        elif name == "sphere_intersects":
            need(2)
            a = self._as_sphere(args[0], name)
            b = self._as_sphere(args[1], name)
            dist = vec_length(vec_sub(a["center"], b["center"]))
            self._push(dist <= a["radius"] + b["radius"])
        elif name == "aabb_contains_point":
            need(2)
            box = self._as_aabb(args[0], name)
            p = self._as_vec(args[1], name, want=3)
            hit = all(box["min"][ax] <= p[ax] <= box["max"][ax] for ax in "xyz")
            self._push(hit)
        elif name == "aabb_sphere_intersects":
            need(2)
            box = self._as_aabb(args[0], name)
            s = self._as_sphere(args[1], name)
            closest = {ax: max(box["min"][ax], min(s["center"][ax], box["max"][ax])) for ax in "xyz"}
            dist = math.sqrt(sum((closest[ax] - s["center"][ax]) ** 2 for ax in "xyz"))
            self._push(dist <= s["radius"])
        elif name == "ray_aabb_intersects":
            need(3)
            origin = self._as_vec(args[0], name, want=3)
            direction = self._as_vec(args[1], name, want=3)
            box = self._as_aabb(args[2], name)
            self._push(self._ray_aabb(origin, direction, box))
        elif name == "min":
            need(2)
            self._push(min(self._as_number(args[0], name), self._as_number(args[1], name)))
        elif name == "max":
            need(2)
            self._push(max(self._as_number(args[0], name), self._as_number(args[1], name)))
        elif name == "clamp":
            need(3)
            v, lo, hi = (self._as_number(a, name) for a in args)
            self._push(max(lo, min(v, hi)))
        elif name == "random":
            need(0)
            self._push(_random.random())
        elif name == "random_range":
            need(2)
            lo, hi = (self._as_number(a, name) for a in args)
            self._push(_random.uniform(lo, hi))
        elif name == "randint":
            need(2)
            lo, hi = (self._as_number(a, name) for a in args)
            self._push(_random.randint(int(lo), int(hi)))
        elif name == "split":
            need(2)
            s, sep = args
            if not isinstance(s, str) or not isinstance(sep, str):
                self._err(f"{name}() requires two strings")
            self._push(s.split(sep) if sep else list(s))
        elif name == "join":
            need(2)
            lst, sep = args
            if not isinstance(lst, list) or not isinstance(sep, str):
                self._err(f"{name}() requires a list and a string")
            if not all(isinstance(x, str) for x in lst):
                self._err(f"{name}(): every item in the list must be a string")
            self._push(sep.join(lst))
        elif name == "trim":
            need(1)
            s = args[0]
            if not isinstance(s, str):
                self._err(f"{name}() requires a string")
            self._push(s.strip())
        elif name == "replace":
            need(3)
            s, old, new = args
            if not all(isinstance(x, str) for x in (s, old, new)):
                self._err(f"{name}() requires three strings")
            self._push(s.replace(old, new))
        elif name == "contains":
            need(2)
            container, item = args
            if isinstance(container, str):
                if not isinstance(item, str):
                    self._err(f"{name}(): searching a string requires a string to look for")
                self._push(item in container)
            elif isinstance(container, list):
                self._push(item in container)
            else:
                self._err(f"{name}() requires a string or list, got {self._type_name(container)}")
        elif name == "index_of":
            need(2)
            container, item = args
            if isinstance(container, str):
                if not isinstance(item, str):
                    self._err(f"{name}(): searching a string requires a string to look for")
                self._push(container.find(item))
            elif isinstance(container, list):
                self._push(container.index(item) if item in container else -1)
            else:
                self._err(f"{name}() requires a string or list, got {self._type_name(container)}")
        elif name == "push":
            need(2)
            lst, item = args
            if not isinstance(lst, list):
                self._err(f"{name}() requires a list, got {self._type_name(lst)}")
            lst.append(item)
            self._push(lst)
        elif name == "pop":
            need(1)
            lst = args[0]
            if not isinstance(lst, list):
                self._err(f"{name}() requires a list, got {self._type_name(lst)}")
            if not lst:
                self._err(f"{name}(): list is empty")
            self._push(lst.pop())
        elif name == "sort":
            need(1)
            lst = args[0]
            if not isinstance(lst, list):
                self._err(f"{name}() requires a list, got {self._type_name(lst)}")
            try:
                self._push(sorted(lst))
            except TypeError:
                self._err(f"{name}(): list items aren't all comparable")
        elif name == "reverse":
            need(1)
            lst = args[0]
            if not isinstance(lst, list):
                self._err(f"{name}() requires a list, got {self._type_name(lst)}")
            self._push(list(reversed(lst)))
        elif name == "slice":
            need(3)
            lst, lo, hi = args
            if not isinstance(lst, list):
                self._err(f"{name}() requires a list, got {self._type_name(lst)}")
            self._push(lst[int(self._as_number(lo, name)):int(self._as_number(hi, name))])
        elif name == "run":
            if len(args) < 1 or not isinstance(args[0], str):
                self._err("run() requires a dotted path string as its first argument, e.g. run(\"math.sqrt\", 16)")
            path, py_args = args[0], args[1:]
            fn = self._resolve_py_path(path, "run")
            if not callable(fn):
                self._err(f"run(): '{path}' is not callable")
            try:
                result = fn(*(self._crt_to_py(a) for a in py_args))
            except Exception as e:
                self._err(f"run(\"{path}\"): {type(e).__name__}: {e}")
            self._push(self._py_to_crt(result))
        else:
            self._err(f"unknown builtin '{name}'")

    def _call_gfx(self, name, argc):
        args = [self._pop() for _ in range(argc)][::-1]

        def as_int(v, what):
            if isinstance(v, bool) or not isinstance(v, (int, float)):
                self._err(f"{name}(): expected a number for {what}, got {self._type_name(v)}")
            return int(v)

        def as_color(r, g, b):
            return (as_int(r, "r") & 255, as_int(g, "g") & 255, as_int(b, "b") & 255)

        if self.gfx is None:
            self.gfx = _PygameBackend(self._err)

        if name == "pygame_init":
            w, h, title = args
            self.gfx.init(as_int(w, "width"), as_int(h, "height"), self._to_display(title) if not isinstance(title, str) else title)
            self._push(None)
        elif name == "pygame_quit":
            self.gfx.quit()
            self._push(None)
        elif name == "pygame_clear":
            if len(args) == 0:
                self.gfx.clear((0, 0, 0))
            else:
                r, g, b = args
                self.gfx.clear(as_color(r, g, b))
            self._push(None)
        elif name == "pygame_rect":
            x, y, w, h, r, g, b = args
            self.gfx.rect(as_int(x, "x"), as_int(y, "y"), as_int(w, "w"), as_int(h, "h"), as_color(r, g, b))
            self._push(None)
        elif name == "pygame_circle":
            x, y, radius, r, g, b = args
            self.gfx.circle(as_int(x, "x"), as_int(y, "y"), as_int(radius, "radius"), as_color(r, g, b))
            self._push(None)
        elif name == "pygame_line":
            x1, y1, x2, y2, r, g, b = args
            self.gfx.line(as_int(x1, "x1"), as_int(y1, "y1"), as_int(x2, "x2"), as_int(y2, "y2"), as_color(r, g, b))
            self._push(None)
        elif name == "pygame_text":
            x, y, text, r, g, b = args
            if not isinstance(text, str):
                text = self._to_display(text)
            self.gfx.text(as_int(x, "x"), as_int(y, "y"), text, as_color(r, g, b))
            self._push(None)
        elif name == "pygame_flip":
            self.gfx.flip()
            self._push(None)
        elif name == "pygame_poll_quit":
            self._push(self.gfx.poll_quit())
        elif name == "pygame_key":
            key_name = args[0]
            if not isinstance(key_name, str):
                self._err("pygame_key(): expected a string key name")
            self._push(self.gfx.key_down(key_name))
        elif name == "pygame_tick":
            fps = args[0]
            if isinstance(fps, bool) or not isinstance(fps, (int, float)):
                self._err("pygame_tick(): expected a number for fps")
            self._push(self.gfx.tick(fps))
        elif name == "pygame_load_image":
            path = args[0]
            if not isinstance(path, str):
                self._err("pygame_load_image() requires a string path")
            self._push(self.gfx.load_image(path))
        elif name == "pygame_draw_image":
            handle, x, y = args
            self.gfx.draw_image(as_int(handle, "handle"), as_int(x, "x"), as_int(y, "y"))
            self._push(None)
        elif name == "pygame_image_size":
            handle = args[0]
            w, h = self.gfx.image_size(as_int(handle, "handle"))
            self._push({"w": w, "h": h})
        elif name == "pygame_load_sound":
            path = args[0]
            if not isinstance(path, str):
                self._err("pygame_load_sound() requires a string path")
            self._push(self.gfx.load_sound(path))
        elif name == "pygame_play_sound":
            handle = args[0]
            self.gfx.play_sound(as_int(handle, "handle"))
            self._push(None)
        elif name == "pygame_stop_sound":
            handle = args[0]
            self.gfx.stop_sound(as_int(handle, "handle"))
            self._push(None)
        elif name == "pygame_set_volume":
            handle, volume = args
            if isinstance(volume, bool) or not isinstance(volume, (int, float)):
                self._err("pygame_set_volume(): expected a number for volume")
            self.gfx.set_volume(as_int(handle, "handle"), float(volume))
            self._push(None)
        elif name == "pygame_mouse_x":
            x, y = self.gfx.mouse_pos()
            self._push(x)
        elif name == "pygame_mouse_y":
            x, y = self.gfx.mouse_pos()
            self._push(y)
        elif name == "pygame_mouse_clicked":
            self._push(self.gfx.mouse_clicked())
        elif name == "pygame_vertex2":
            x, y = args
            self._push({"__v__": 2,
                        "x": self._as_number(x, "pygame_vertex2"),
                        "y": self._as_number(y, "pygame_vertex2")})
        elif name == "pygame_vertex3":
            x, y, z = args
            self._push({"__v__": 3,
                        "x": self._as_number(x, "pygame_vertex3"),
                        "y": self._as_number(y, "pygame_vertex3"),
                        "z": self._as_number(z, "pygame_vertex3")})
        elif name == "pygame_polygon":
            if len(args) == 1:
                verts, color_arg = args[0], None
            else:
                verts, r, g, b = args
                color_arg = as_color(r, g, b)
            points = self._project_polygon_points(verts, name)
            if points is not None:
                self.gfx.polygon(points, color_arg if color_arg is not None else (255, 255, 255))
            self._push(None)
        elif name == "pygame_polygon_texture":
            verts, handle, uvs = args
            points = self._project_polygon_points(verts, name)
            uv_pairs = self._as_uv_list(uvs, name)
            if len(uv_pairs) != len(self._as_vertex_list(verts, name)):
                self._err(f"{name}(): needs one uv per vertex")
            if points is not None:
                self.gfx.polygon_texture(points, as_int(handle, "handle"), uv_pairs)
            self._push(None)
        elif name == "pygame_camera":
            handle = self.gfx.new_camera()
            self._push({"__native__": "camera", "__id__": handle})
        elif name == "pygame_object":
            handle = self.gfx.new_object()
            self._push({"__native__": "object", "__id__": handle})
        else:
            self._err(f"unknown graphics builtin '{name}'")

    # ---- vertex/polygon helpers -----------------------------------------

    def _as_vertex_list(self, verts, caller):
        if not isinstance(verts, list):
            self._err(f"{caller}(): expected a list of vertices, got {self._type_name(verts)}")
        if len(verts) < 3:
            self._err(f"{caller}(): needs at least 3 vertices, got {len(verts)}")
        for v in verts:
            if not isinstance(v, dict) or "__v__" not in v:
                self._err(f"{caller}(): list items must be vertices made with "
                           f"pygame_vertex2()/pygame_vertex3()")
        return verts

    def _as_uv_list(self, uvs, caller):
        if not isinstance(uvs, list):
            self._err(f"{caller}(): expected a list of uvs, got {self._type_name(uvs)}")
        out = []
        for uv in uvs:
            if not isinstance(uv, dict) or "u" not in uv or "v" not in uv:
                self._err(f"{caller}(): each uv must be an object with 'u' and 'v', "
                          f"e.g. {{u: 0.0, v: 1.0}}")
            u = self._as_number(uv["u"], caller)
            v = self._as_number(uv["v"], caller)
            out.append((float(u), float(v)))
        return out

    def _project_polygon_points(self, verts, caller):
        """Turns a list of pygame_vertex2/pygame_vertex3 objects into
        screen-pixel (x, y) points, projecting 3D ones through the active
        camera. Returns None (meaning: skip drawing this frame) if any 3D
        vertex falls behind the camera -- a flat, uncomplicated way to
        avoid drawing a face that isn't actually in view, without a full
        clipping pipeline."""
        vlist = self._as_vertex_list(verts, caller)
        kinds = {v["__v__"] for v in vlist}
        if len(kinds) > 1:
            self._err(f"{caller}(): can't mix 2D and 3D vertices in one polygon")
        is_3d = 2 not in kinds

        if self.gfx is None:
            self.gfx = _PygameBackend(self._err)

        points = []
        if is_3d:
            for v in vlist:
                proj = self.gfx.project_vertex((v["x"], v["y"], v["z"]), caller)
                if proj is None:
                    return None
                points.append((int(proj[0]), int(proj[1])))
        else:
            for v in vlist:
                points.append((int(v["x"]), int(v["y"])))
        return points

    def _call_native_method(self, receiver, method, args):
        """Dispatches a method call on a native (non-user-class) object,
        e.g. a pygame_camera() instance. Called from CALL_METHOD's runtime
        handler before it falls back to looking up a real class method."""
        kind = receiver["__native__"]
        methods = NATIVE_METHODS.get(kind, {})
        if method not in methods:
            self._err(f"'{kind}' object has no method '{method}'")
        expected = methods[method]
        allowed = expected if isinstance(expected, tuple) else (expected,)
        if len(args) not in allowed:
            choices = " or ".join(str(n) for n in allowed)
            self._err(f"'{kind}.{method}' takes {choices} argument(s), got {len(args)}")

        if kind == "camera":
            cam = self.gfx.get_camera(receiver["__id__"], f"{kind}.{method}") if self.gfx else None
            if cam is None:
                self._err(f"{kind}.{method}(): camera is no longer valid "
                          f"(was the window closed with pygame_quit()?)")
            if method == "pos":
                x, y, z = args
                cam.x = float(self._as_number(x, "pos"))
                cam.y = float(self._as_number(y, "pos"))
                cam.z = float(self._as_number(z, "pos"))
                return None
            elif method == "rotate":
                yaw, pitch = args
                cam.yaw = float(self._as_number(yaw, "rotate"))
                cam.pitch = float(self._as_number(pitch, "rotate"))
                return None
            elif method == "fov":
                fov = args[0]
                fov = float(self._as_number(fov, "fov"))
                if fov <= 0 or fov >= 180:
                    self._err("camera.fov(): degrees must be between 0 and 180")
                cam.fov = fov
                return None
            elif method == "look_at":
                target = self._as_vec(args[0], "look_at", want=3)
                cam.look_at(target["x"], target["y"], target["z"])
                return None
            elif method == "orbit":
                target = self._as_vec(args[0], "orbit", want=3)
                distance = float(self._as_number(args[1], "orbit"))
                cam.orbit(target["x"], target["y"], target["z"], distance)
                return None
            elif method == "forward":
                fx, fy, fz = cam.forward_vec()
                return make_vec(fx, fy, fz)
            elif method == "position":
                return make_vec(cam.x, cam.y, cam.z)
            self._err(f"unimplemented native method '{kind}.{method}'")

        if kind == "object":
            if self.gfx is None:
                self._err(f"object.{method}(): call pygame_init() before using graphics")

            def as_channel(v, what):
                if isinstance(v, bool) or not isinstance(v, (int, float)):
                    self._err(f"object.{method}(): expected a number for {what}, got {self._type_name(v)}")
                return int(v) & 255

            if method == "rectangle":
                w, h, r, g, b = args
                w = float(self._as_number(w, "rectangle"))
                h = float(self._as_number(h, "rectangle"))
                color = (as_channel(r, "r"), as_channel(g, "g"), as_channel(b, "b"))
                self.gfx.object_rectangle(receiver["__id__"], w, h, color)
                return None
            elif method == "pos":
                obj = self.gfx.get_object(receiver["__id__"], "pygame_object.pos")
                if len(args) == 0:
                    return obj.get_pos_vec()
                elif len(args) == 2:
                    x, y = args
                    obj.set_pos2(float(self._as_number(x, "pos")), float(self._as_number(y, "pos")))
                else:
                    x, y, z = args
                    obj.set_pos3(float(self._as_number(x, "pos")), float(self._as_number(y, "pos")),
                                 float(self._as_number(z, "pos")))
                return None
            elif method == "clicked":
                return self.gfx.object_clicked(receiver["__id__"])
            elif method == "draw":
                self.gfx.object_draw(receiver["__id__"])
                return None
            self._err(f"unimplemented native method '{kind}.{method}'")

        self._err(f"unimplemented native method '{kind}.{method}'")

    # ---- main loop -----------------------------------------------------

    def run(self):
        instrs = self.instructions
        n = len(instrs)
        while self.pc < n:
            ins = instrs[self.pc]
            op = REV_OPCODES.get(ins.op)
            if op is None:
                self._err(f"invalid opcode 0x{ins.op:02x}")

            if op == "HALT":
                return
            elif op == "PUSH_INT":
                self._push(ins.arg_val)
            elif op == "PUSH_FLOAT":
                self._push(float(self.strings[ins.arg_val]))
            elif op == "PUSH_STR":
                self._push(self.strings[ins.arg_val])
            elif op == "PUSH_BOOL":
                self._push(bool(ins.arg_val))
            elif op == "PUSH_NULL":
                self._push(None)
            elif op == "POP":
                self._pop()
            elif op == "DUP":
                if not self.stack:
                    self._err("stack underflow")
                self._push(self.stack[-1])
            elif op == "LOAD":
                self._push(self._load(self.strings[ins.arg_val]))
            elif op == "STORE":
                self._store(self.strings[ins.arg_val], self._pop())
            elif op == "STORE_LOCAL":
                self._store_local(self.strings[ins.arg_val], self._pop())
            elif op in ("ADD", "SUB", "MUL", "DIV", "MOD"):
                self._arith(op)
            elif op in ("EQ", "NEQ", "LT", "GT", "LTE", "GTE"):
                self._compare(op)
            elif op == "NEG":
                v = self._pop()
                if isinstance(v, dict) and "__vec__" in v:
                    self._push(vec_neg(v))
                elif not isinstance(v, (int, float)) or isinstance(v, bool):
                    self._err(f"cannot negate {self._type_name(v)}")
                else:
                    self._push(-v)
            elif op == "NOT":
                self._push(not self._truthy(self._pop()))
            elif op == "PRINT":
                self.out.write(self._to_display(self._pop()) + "\n")
            elif op == "JUMP":
                self.pc = ins.arg_val
                continue
            elif op == "JUMP_IF_FALSE":
                if not self._truthy(self._pop()):
                    self.pc = ins.arg_val
                    continue
            elif op == "JUMP_IF_TRUE":
                if self._truthy(self._pop()):
                    self.pc = ins.arg_val
                    continue
            elif op == "MAKE_LIST":
                count = ins.arg_val
                items = [self._pop() for _ in range(count)][::-1]
                self._push(items)
            elif op == "MAKE_OBJECT":
                count = ins.arg_val
                obj = {}
                pairs = []
                for _ in range(count):
                    val = self._pop()
                    key = self._pop()
                    pairs.append((key, val))
                for key, val in reversed(pairs):
                    obj[key] = val
                self._push(obj)
            elif op == "GET_MEMBER":
                obj = self._pop()
                name = self.strings[ins.arg_val]
                if not isinstance(obj, dict):
                    self._err(f"cannot access member '{name}' on {self._type_name(obj)}")
                if name not in obj:
                    self._err(f"object has no member '{name}'")
                self._push(obj[name])
            elif op == "SET_MEMBER":
                val = self._pop()
                obj = self._pop()
                name = self.strings[ins.arg_val]
                if not isinstance(obj, dict):
                    self._err(f"cannot set member '{name}' on {self._type_name(obj)}")
                obj[name] = val
            elif op == "GET_INDEX":
                idx = self._pop()
                obj = self._pop()
                try:
                    if isinstance(obj, list):
                        if not isinstance(idx, int) or isinstance(idx, bool):
                            self._err("list index must be an int")
                        self._push(obj[idx])
                    elif isinstance(obj, dict):
                        self._push(obj[idx])
                    elif isinstance(obj, str):
                        self._push(obj[idx])
                    else:
                        self._err(f"cannot index into {self._type_name(obj)}")
                except IndexError:
                    self._err("index out of range")
                except KeyError:
                    self._err(f"object has no key '{idx}'")
            elif op == "SET_INDEX":
                val = self._pop()
                idx = self._pop()
                obj = self._pop()
                if isinstance(obj, list):
                    if not isinstance(idx, int) or isinstance(idx, bool):
                        self._err("list index must be an int")
                    # Match GET_INDEX's Python-style negative indexing
                    # (l[-1] reads the last element) instead of only
                    # allowing it for reads and erroring on writes.
                    norm_idx = idx + len(obj) if idx < 0 else idx
                    if norm_idx < 0 or norm_idx >= len(obj):
                        self._err("index out of range")
                    obj[norm_idx] = val
                elif isinstance(obj, dict):
                    obj[idx] = val
                else:
                    self._err(f"cannot assign into {self._type_name(obj)}")
            elif op == "MAKE_FRAME":
                # Enter a new local scope for a function call. The CALL
                # opcode already pushed the arguments and jumped here; this
                # instruction opens the local frame so the STOREs that
                # immediately follow (one per parameter, compiled in
                # reverse) bind into local scope instead of globals.
                self.frames.append(Frame(return_addr=self._pending_return_addr))
            elif op == "CALL":
                name = self.strings[ins.arg_val]
                argc = ins.extra
                if name not in self.func_table:
                    self._err(f"call to undefined function '{name}'")
                addr, arity = self.func_table[name]
                if argc != arity:
                    self._err(f"'{name}' takes {arity} argument(s), got {argc}")
                args = [self._pop() for _ in range(argc)][::-1]
                self._pending_return_addr = self.pc + 1
                self.pc = addr
                # args is now in original left-to-right parameter order,
                # e.g. [a_val, b_val]. The function body's STOREs run in
                # reversed(params) order (last param first), so the LAST
                # param's value must be on top of the stack. Pushing args
                # in order (not reversed) puts a_val down first and b_val
                # on top -- exactly what the first STORE (for b) needs.
                for a in args:
                    self._push(a)
                continue
            elif op == "CALL_METHOD":
                method = self.strings[ins.arg_val]
                argc = ins.extra
                args = [self._pop() for _ in range(argc)][::-1]
                if not self.stack:
                    self._err("stack underflow")
                receiver = self._pop()
                if isinstance(receiver, dict) and "__native__" in receiver:
                    result = self._call_native_method(receiver, method, args)
                    self._push(result)
                    self.pc += 1
                    continue
                if not isinstance(receiver, dict) or "__class__" not in receiver:
                    self._err(f"cannot call method '{method}' on {self._type_name(receiver)}")
                cls_name = receiver["__class__"]
                name = f"{cls_name}.{method}"
                if name not in self.func_table:
                    self._err(f"'{cls_name}' has no method '{method}'")
                addr, arity = self.func_table[name]
                if argc != arity - 1:
                    self._err(f"'{cls_name}.{method}' takes {arity - 1} argument(s), got {argc}")
                self._pending_return_addr = self.pc + 1
                self.pc = addr
                self._push(receiver)
                for a in args:
                    self._push(a)
                continue
            elif op == "CALL_BUILTIN":
                name = self.strings[ins.arg_val]
                self._call_builtin(name, ins.extra)
            elif op == "CALL_GFX":
                name = self.strings[ins.arg_val]
                self._call_gfx(name, ins.extra)
            elif op == "PY_IMPORT":
                module_path = self.strings[ins.arg_val]
                self._py_import(module_path)
            elif op == "RET":
                retval = self._pop()
                if not self.frames:
                    self._err("'return' outside of a function")
                frame = self.frames.pop()
                self.pc = frame.return_addr
                self._push(retval)
                continue
            else:
                self._err(f"unimplemented opcode: {op}")

            self.pc += 1


def run_module(module, out=None):
    CVM(module, out=out).run()


def run_source(code, out=None):
    """Convenience: compile then immediately execute source text."""
    data = compile_source(code)
    module = load_module(data)
    run_module(module, out=out)


# =====================================================================
# 5. CLI / REPL / DISASSEMBLER
# =====================================================================

def disassemble(module, file=sys.stdout):
    """Human-readable listing of a loaded CVM module."""
    file.write(f"; CVM disassembly ({len(module.instructions)} instructions, "
               f"{len(module.strings)} strings)\n")
    if module.strings:
        file.write(";\n; string table:\n")
        for i, s in enumerate(module.strings):
            file.write(f";   [{i}] {s!r}\n")
    file.write(";\n")
    for addr, ins in enumerate(module.instructions):
        name = REV_OPCODES.get(ins.op, f"0x{ins.op:02x}")
        operand = ""
        if ins.arg_type == ARG_STR:
            s = module.strings[ins.arg_val] if 0 <= ins.arg_val < len(module.strings) else "?"
            operand = f" {ins.arg_val} ; {s!r}"
        elif ins.arg_type == ARG_IMM:
            operand = f" {ins.arg_val}"
        extra = f"  (extra={ins.extra})" if ins.extra else ""
        file.write(f"{addr:6d}: {name:<16}{operand}{extra}\n")


def _read_file(path):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return f.read()
    except OSError as e:
        print(f"crt: cannot read '{path}': {e}", file=sys.stderr)
        sys.exit(1)


def cmd_run(args):
    code = _read_file(args.file)
    try:
        run_source(code)
    except CRTError as e:
        print(f"crt: {e.format()}", file=sys.stderr)
        sys.exit(1)


def cmd_build(args):
    code = _read_file(args.file)
    try:
        data = compile_source(code)
    except CRTError as e:
        print(f"crt: {e.format()}", file=sys.stderr)
        sys.exit(1)
    out_path = args.output or (os.path.splitext(args.file)[0] + ".cvm")
    with open(out_path, "wb") as f:
        f.write(data)
    print(f"crt: wrote {out_path} ({len(data)} bytes)")


def cmd_exec(args):
    try:
        with open(args.file, "rb") as f:
            data = f.read()
    except OSError as e:
        print(f"crt: cannot read '{args.file}': {e}", file=sys.stderr)
        sys.exit(1)
    try:
        module = load_module(data)
        run_module(module)
    except CRTError as e:
        print(f"crt: {e.format()}", file=sys.stderr)
        sys.exit(1)


def cmd_disasm(args):
    try:
        with open(args.file, "rb") as f:
            data = f.read()
    except OSError as e:
        print(f"crt: cannot read '{args.file}': {e}", file=sys.stderr)
        sys.exit(1)
    try:
        module = load_module(data)
    except CRTError as e:
        print(f"crt: {e.format()}", file=sys.stderr)
        sys.exit(1)
    disassemble(module)


def cmd_asm(args):
    text = _read_file(args.file)
    try:
        data = assemble_source(text)
    except CRTError as e:
        print(f"crt: {e.format()}", file=sys.stderr)
        sys.exit(1)
    out_path = args.output or (os.path.splitext(args.file)[0] + ".cvm")
    with open(out_path, "wb") as f:
        f.write(data)
    print(f"crt: wrote {out_path} ({len(data)} bytes)")


CHEAT_SHEET = """\
CRT CHEAT SHEET
================

VARIABLES
    let x = 5;                 declare
    x = 6;                     reassign (walks up to an existing outer
                                binding first; only creates a new local
                                if the name isn't bound anywhere yet)

TYPES
    5            int
    3.5          float
    "hi"  'hi'   string          (both quote styles work)
    true  false  bool
    null         null
    [1, 2, 3]    list
    {a: 1}       object

OPERATORS
    + - * / %              arithmetic (/ gives a float unless exact)
    == != < > <= >=        comparison
    && || !                logic       (also: and, or, not)
    -x                     unary minus

STRINGS
    "a" + "b"               concatenation
    "line\\nbreak\\ttab"     escapes: \\n \\t \\r \\" \\' \\\\ \\0

COMMENTS
    // line comment
    /* block
       comment */

CONTROL FLOW
    if (cond) { ... } else if (cond) { ... } else { ... }
    while (cond) { ... }
    for (let i = 0; i < 10; i = i + 1) { ... }
    break;
    continue;

FUNCTIONS
    fn add(a, b) {
        return a + b;
    }
    add(1, 2);                  recursion and mutual recursion both work

LISTS & OBJECTS
    let l = [1, 2, 3];
    l[0];  l[0] = 9;             negative indices work too: l[-1]
    let o = {name: "crt", n: 1};
    o.name;  o.name = "x";
    o["name"];  o["name"] = "x"; bracket access works for objects too

CLASSES -- see `crt demo classes` for full detail, including imports
    class Counter {
        fn new(start) { self.n = start; }
        fn inc() { self.n = self.n + 1; return self.n; }
    }
    let c = Counter(10);
    c.inc();                    instance method call -> 11

BUILT-IN FUNCTIONS
    len(x)          length of a string, list, or object
    str(x)           convert to string
    int(x)            convert to int
    float(x)           convert to float
    type(x)             "int" "float" "string" "bool" "null" "list" "object"
    upper(s)  lower(s)   string case

    json_encode(x)        encode a value as a JSON string
    json_decode(s)          parse a JSON string into a value

    file_read(path)              -> file contents as a string
    file_write(path, content)     overwrite a file with content
    file_append(path, content)     append content to a file
    file_exists(path)                -> true/false
    file_delete(path)                  delete a file

    pi()  e()  tau()        math constants, called like zero-arg functions
    sin(x) cos(x) tan(x)      trig (radians in, radians out)
    asin(x) acos(x) atan(x)    inverse trig -> radians
    atan2(y, x)                  angle of (x, y) -> radians
    sinh(x) cosh(x) tanh(x)        hyperbolic
    asinh(x) acosh(x) atanh(x)      inverse hyperbolic
    sqrt(x)  pow(base, exp)  exp(x)   roots / powers / e^x
    log(x)  log(x, base)  log2(x)  log10(x)   logarithms
    floor(x)  ceil(x)  round(x)  round(x, n)   rounding
    abs(x)                             absolute value
    deg(radians)  rad(degrees)           angle unit conversion

GRAPHICS (pygame mode) -- see `crt demo graphics` for full detail,
including textures, 3D, and audio
    pygame_init(w, h, title)     open a window
    pygame_clear()                 clear to black
    pygame_clear(r, g, b)           clear to a color
    pygame_rect(x, y, w, h, r, g, b)
    pygame_circle(x, y, radius, r, g, b)
    pygame_line(x1, y1, x2, y2, r, g, b)
    pygame_text(x, y, text, r, g, b)
    pygame_flip()                  show the frame you just drew
    pygame_poll_quit()               true if the window's X was clicked
    pygame_key(name)                   true if that key is held
    pygame_tick(fps)                     caps framerate, returns ms elapsed
    pygame_quit()                          close the window
    pygame_load_image / draw_image / image_size    textures (needs Pillow)
    pygame_load_sound / play_sound / stop_sound / set_volume    audio
    pygame_mouse_x() / pygame_mouse_y()            current mouse position
    pygame_mouse_clicked()                          true on left-click
    pygame_vertex2(x, y) / pygame_vertex3(x, y, z)  2D/3D points
    pygame_polygon(verts) / pygame_polygon(verts, r, g, b)   fill them
    pygame_polygon_texture(verts, image_handle, uvs)   textured fill
    pygame_camera()                    a.pos/a.rotate/a.fov -- 3D camera

CLI
    crt run file.ct                  run a .ct file directly
    crt build file.ct -o file.cvm    compile to bytecode
    crt exec file.cvm                run compiled bytecode
    crt disasm file.cvm              disassemble bytecode
    crt asm file.asm -o file.cvm     assemble CRT assembly to bytecode
    crt                              interactive REPL
    crt demo                         this cheat sheet
    crt demo graphics                graphics + textures + audio cheat sheet
    crt demo classes                 classes + imports cheat sheet
    crt demo asm                     CRT assembly language cheat sheet
"""

GRAPHICS_CHEAT_SHEET = """\
CRT GRAPHICS CHEAT SHEET (pygame mode)
=======================================

Calling any pygame_* function opens a real window and enters graphics
mode. These are ordinary builtin functions -- usable anywhere a normal
call is, with the same argument-count checking as user functions.

    pygame_init(width, height, title)
        Opens the window. Call this first, once.

    pygame_clear()
        Clears the frame to black. Shorthand for pygame_clear(0, 0, 0).

    pygame_clear(r, g, b)
        Clears/fills the whole frame with a color. Call this at the
        start of every loop iteration before drawing, the same way you'd
        clear a canvas before repainting it.

    pygame_rect(x, y, w, h, r, g, b)
        Filled rectangle, top-left corner at (x, y).

    pygame_circle(x, y, radius, r, g, b)
        Filled circle centered at (x, y).

    pygame_line(x1, y1, x2, y2, r, g, b)
        Line from (x1, y1) to (x2, y2).

    pygame_text(x, y, text, r, g, b)
        Draws text with its top-left at (x, y).

    pygame_flip()
        Presents everything you drew this frame. Nothing appears on
        screen until you call this.

    pygame_poll_quit()
        Returns true once, the moment the window's close button (X) is
        clicked. Check this every loop iteration to exit cleanly.

    pygame_key(name)
        Returns true while a key is held down. Names: left right up
        down space enter escape shift ctrl tab, or any single letter
        or digit ("a".."z", "0".."9").

    pygame_tick(fps)
        Caps the loop to roughly `fps` frames per second and returns
        the milliseconds elapsed since the last call. Call it once per
        loop iteration, usually last.

    pygame_quit()
        Closes the window. Call this after the loop ends.

Colors are (r, g, b), each 0-255. Coordinates accept floats and are
truncated to whole pixels automatically.

MOUSE
    pygame_mouse_x()
    pygame_mouse_y()
        Current mouse position in window coordinates, updated live.

    pygame_mouse_clicked()
        Returns true once, on the frame the left mouse button was
        pressed down (same edge-triggered pattern as pygame_poll_quit).
        Check this every loop iteration if you want to catch every click.

TEXTURES (needs Pillow: pip install Pillow)
    pygame_load_image(path)
        Loads an image file into a texture and returns an integer
        handle to it. Call once, ahead of time (e.g. before the loop).

    pygame_draw_image(handle, x, y)
        Draws a loaded texture with its top-left corner at (x, y).

    pygame_image_size(handle)
        Returns {w: ..., h: ...} for a loaded texture.

AUDIO (uses pygame's mixer, initialized lazily on first use)
    pygame_load_sound(path)
        Loads a sound file (wav/ogg) and returns an integer handle.

    pygame_play_sound(handle)
        Plays a loaded sound. Can be called repeatedly to layer plays.

    pygame_stop_sound(handle)
        Stops a loaded sound if it's currently playing.

    pygame_set_volume(handle, volume)
        Sets a loaded sound's volume, 0.0 (silent) to 1.0 (full).

2D/3D VERTICES & POLYGONS
    pygame_vertex2(x, y)
        A 2D vertex: a point in screen pixels.

    pygame_vertex3(x, y, z)
        A 3D vertex: a point in world space, viewed through a camera.

    pygame_polygon(vertices)
        Fills a polygon (white) from 3 or more vertices. All vertices in
        the list must be the same kind -- all pygame_vertex2(), or all
        pygame_vertex3(). 2D vertices draw straight to the screen; 3D
        ones are projected through whichever pygame_camera() was created
        most recently. A 3D face that ends up entirely behind the camera
        is silently skipped that frame rather than drawn wrong.

    pygame_polygon(vertices, r, g, b)
        Same, filled with one flat color instead of white.

    pygame_polygon_texture(vertices, image_handle, uvs)
        Fills a polygon with a texture (from pygame_load_image()) instead
        of a flat color. uvs is a list of {u, v} objects, each 0.0-1.0,
        one per vertex, in the same order as `vertices` -- they say which
        part of the image maps to which corner. Works with 2D or 3D
        vertices exactly like pygame_polygon() does. Needs Pillow.

3D CAMERA
    pygame_camera()
        Creates a 3D camera and returns it. Not a class -- it's a plain
        object you call these on directly:

    a.pos(x, y, z)
        Moves the camera to a world position. Starts at (0, 0, 0).

    a.rotate(yaw, pitch)
        Turns the camera, in degrees. yaw turns left/right, pitch tilts
        up/down. Starts at (0, 0), looking down +z.

    a.fov(degrees)
        Sets the vertical field of view. Starts at 70 degrees. Must be
        between 0 and 180.

    Only the most recently created camera is used to project 3D
    vertices -- if a script only ever makes one camera, this never
    matters. pygame_vertex3()-based polygons need a camera to exist
    before they're drawn; there's nothing to project through otherwise.

    let cam = pygame_camera();
    cam.pos(0, 0, -5);

    let v1 = pygame_vertex3(-1, -1, 0);
    let v2 = pygame_vertex3( 1, -1, 0);
    let v3 = pygame_vertex3( 0,  1, 0);

    pygame_clear();
    pygame_polygon([v1, v2, v3], 255, 0, 0);
    pygame_flip();

    See examples_3d_demo.ct for a full spinning-cube example:
    crt run examples_3d_demo.ct   (needs pygame and Pillow)

MINIMAL GAME LOOP
    pygame_init(640, 480, "My Game");
    let running = true;
    while (running) {
        if (pygame_poll_quit()) { running = false; }
        if (pygame_key("escape")) { running = false; }
        if (pygame_mouse_clicked()) {
            print(pygame_mouse_x());
            print(pygame_mouse_y());
        }

        // ...update state here...

        pygame_clear();
        pygame_circle(100, 100, 20, 255, 0, 0);
        pygame_flip();
        pygame_tick(60);
    }
    pygame_quit();
"""

ASM_CHEAT_SHEET = """\
CRT ASSEMBLY CHEAT SHEET
=========================

`crt asm file.asm -o file.cvm` assembles hand-written CVM assembly text
into the same .cvm bytecode format `crt build` produces -- runnable with
`crt exec` and inspectable with `crt disasm`. A `crt disasm` listing is
close enough to valid assembly that editing one is a good way to learn.

SYNTAX
    ; a comment, to end of line
    label:                  define a label (address of the next
                             instruction) -- usable as a jump target
    .func name arity        mark the next instruction's address as the
                             entry point of function `name`, which takes
                             `arity` parameters
    MNEMONIC                instruction with no operand
    MNEMONIC 42              instruction with an integer operand
    MNEMONIC "text"           instruction with a string operand
    MNEMONIC 3.5               float literal operand
    MNEMONIC label               a label used as a jump target
    MNEMONIC "name", 2             string operand plus an extra field
                                     (e.g. argument count for CALL)

Any bare identifier operand that isn't a defined label is an error
(undefined label) rather than silently assembling as address 0.

INSTRUCTIONS
    PUSH_INT n            PUSH_FLOAT f          PUSH_STR "s"
    PUSH_BOOL 0/1         PUSH_NULL             DUP  POP
    ADD SUB MUL DIV MOD                         (pop 2, push 1)
    EQ NEQ LT GT LTE GTE                        (pop 2, push 1)
    NEG NOT                                     (pop 1, push 1)
    LOAD "name"           STORE "name"          STORE_LOCAL "name"
    JUMP addr             JUMP_IF_TRUE addr     JUMP_IF_FALSE addr
    MAKE_FRAME n          RET                   HALT
    CALL "name", argc     CALL_BUILTIN "name", argc
    CALL_GFX "name", argc (pygame_* builtins)
    CALL_METHOD "name", argc   dynamic dispatch: pops argc args, then a
                                receiver object, reads its __class__, and
                                calls "<class>.<name>" with the receiver
                                re-pushed as the method's implicit first
                                (self) argument -- see `crt demo classes`
    MAKE_LIST n           MAKE_OBJECT n
    GET_INDEX  SET_INDEX  GET_MEMBER "k"  SET_MEMBER "k"

MINIMAL EXAMPLE (prints 15)
    PUSH_INT 5
    PUSH_INT 10
    ADD
    PRINT
    HALT

A FUNCTION, CALLED FROM TOP LEVEL
    JUMP main            ; skip over the function body
.func add 2
add:
    MAKE_FRAME 2
    STORE_LOCAL "b"      ; params pop off in reverse order
    STORE_LOCAL "a"
    LOAD "a"
    LOAD "b"
    ADD
    RET
main:
    PUSH_INT 3
    PUSH_INT 4
    CALL "add", 2
    PRINT
    HALT

A CLASS INSTANCE, CALLED FROM TOP LEVEL
    Function names may contain dots (e.g. "Counter.new"), used as both
    string operands and labels, so hand-written assembly can define and
    call class methods the same way `crt build` compiles them.

    JUMP main
.func Counter.new 2
Counter.new:
    MAKE_FRAME 2
    STORE_LOCAL "start"
    STORE_LOCAL "self"     ; self is just the method's first parameter
    LOAD "self"
    LOAD "start"
    SET_MEMBER "n"
    PUSH_NULL
    RET
.func Counter.value 1
Counter.value:
    MAKE_FRAME 1
    STORE_LOCAL "self"
    LOAD "self"
    GET_MEMBER "n"
    RET
main:
    MAKE_OBJECT 0
    DUP
    PUSH_STR "Counter"
    SET_MEMBER "__class__"   ; tag the object so CALL_METHOD can find it
    DUP
    PUSH_INT 42
    CALL "Counter.new", 2    ; construct: explicit call, self + 1 arg
    POP                      ; discard new()'s return value
    CALL_METHOD "value", 0   ; dynamic dispatch by __class__, no args
    PRINT                    ; -> 42
    HALT
"""


CLASSES_CHEAT_SHEET = """\
CRT CLASSES & IMPORTS CHEAT SHEET
===================================

CLASSES
    class Counter {
        fn new(start) {         constructor -- runs automatically when
            self.n = start;     the class is called like a function
        }
        fn inc() {
            self.n = self.n + 1;
            return self.n;
        }
        fn value() {
            return self.n;
        }
    }

    let c = Counter(10);        constructs an instance, runs new(10)
    c.inc();                    -> 11   (instance method call)
    c.inc();                    -> 12
    c.value();                  -> 12

    `self` is an ordinary variable, bound automatically as the first
    (hidden) parameter of every method -- inside a method it refers to
    the instance the method was called on, and self.x reads/writes
    per-instance state exactly like any other object's members.

    A class doesn't need a `new` method; without one, Classname() just
    makes an empty instance ready for its other methods to fill in.
    Calling Classname(...) with arguments when there's no `new` to
    receive them is a compile-time error.

IMPORTS -- reusing a class compiled somewhere else
    Classes are often more useful split into their own file and shared,
    the same way a library is. Compile the file that declares the class,
    then pull it into another script by name:

        crt build nn.ct -o nn.cvm

    nn.ct:
        class Neuralnetwork {
            fn new(w1, i) { self.w1 = w1; self.i = i; }
            fn train(i, o) {
                self.w1 = self.w1 + (i * o);
                return self.w1;
            }
        }

    main.ct:
        import Neuralnetwork from "nn.cvm";

        let net = Neuralnetwork(5, 2);
        print(net.train(1, 3));     -> 8
        print(net.train(2, 2));     -> 12

    `import Name from "file.cvm";` is resolved at compile time: the
    named class's compiled methods are copied straight into the
    importing script's own bytecode, so the resulting .cvm from
    `crt build main.ct` is fully self-contained -- nn.cvm doesn't need
    to travel with it, and `crt run` / `crt exec` don't re-read it.

    Once imported, a class's methods can also be called directly by
    name without constructing an instance, like a namespace of plain
    functions -- handy for stateless helper libraries:

        import Mathy from "mathlib.cvm";
        print(Mathy.add(3, 4));     -> 7

    Import errors (file not found, or the named class/function doesn't
    exist in it) are caught at compile time with a clear message rather
    than failing later at runtime.
"""


def cmd_demo(args):
    topic = getattr(args, "topic", None)
    if topic == "graphics":
        print(GRAPHICS_CHEAT_SHEET, end="")
    elif topic == "asm":
        print(ASM_CHEAT_SHEET, end="")
    elif topic == "classes":
        print(CLASSES_CHEAT_SHEET, end="")
    else:
        print(CHEAT_SHEET, end="")


def repl():
    print("crt REPL - type 'exit' or Ctrl-D to quit")
    vm_globals = {}
    fn_source = []   # accumulated function declarations (persist across turns)
    pending = ""
    while True:
        try:
            prompt = "crt> " if not pending else "...> "
            line = input(prompt)
        except (EOFError, KeyboardInterrupt):
            print()
            break
        if not pending and line.strip() in ("exit", "quit"):
            break
        pending += line + "\n"
        if pending.count("{") > pending.count("}"):
            continue
        source = pending
        pending = ""
        try:
            tokens = tokenize(source)
            ast = Parser(tokens).parse()
        except CRTError as e:
            print(f"error: {e.format()}")
            continue

        new_fn_decls = [s for s in ast.stmts if isinstance(s, FuncDeclNode)]
        other_stmts = [s for s in ast.stmts if not isinstance(s, FuncDeclNode)]

        # Recompile every function ever declared this session plus just the
        # new non-function statements from this turn, so earlier fn defs
        # stay callable without re-running earlier print()s etc.
        full_ast = ProgramNode(fn_source + new_fn_decls + other_stmts)
        try:
            compiler = BinaryCompiler()
            compiler.compile_program(full_ast)
            _verify_calls(full_ast, compiler)
            data = compiler.assemble()
            module = load_module(data)
            vm = CVM(module)
            vm.globals = vm_globals
            vm.run()
            vm_globals.update(vm.globals)
            fn_source.extend(new_fn_decls)
        except CRTError as e:
            print(f"error: {e.format()}")
        except Exception as e:  # pragma: no cover - safety net for REPL use
            print(f"internal error: {e}")


def main(argv=None):
    parser = argparse.ArgumentParser(prog="crt", description="CRT language toolchain")
    sub = parser.add_subparsers(dest="command")

    p_run = sub.add_parser("run", help="Run a .ct source file directly")
    p_run.add_argument("file")
    p_run.set_defaults(func=cmd_run)

    p_build = sub.add_parser("build", help="Compile a .ct file to .cvm bytecode")
    p_build.add_argument("file")
    p_build.add_argument("-o", "--output", help="Output .cvm path")
    p_build.set_defaults(func=cmd_build)

    p_exec = sub.add_parser("exec", help="Execute a compiled .cvm file")
    p_exec.add_argument("file")
    p_exec.set_defaults(func=cmd_exec)

    p_disasm = sub.add_parser("disasm", help="Disassemble a compiled .cvm file")
    p_disasm.add_argument("file")
    p_disasm.set_defaults(func=cmd_disasm)

    p_asm = sub.add_parser("asm", help="Assemble a .asm file to .cvm bytecode")
    p_asm.add_argument("file")
    p_asm.add_argument("-o", "--output", help="Output .cvm path")
    p_asm.set_defaults(func=cmd_asm)

    p_demo = sub.add_parser("demo", help="Print a CRT language cheat sheet")
    p_demo.add_argument("topic", nargs="?", choices=["graphics", "asm", "classes"],
                         help="Optional: 'graphics', 'asm', or 'classes' for those cheat sheets")
    p_demo.set_defaults(func=cmd_demo)

    args = parser.parse_args(argv)
    if not getattr(args, "command", None):
        repl()
        return
    args.func(args)


if __name__ == "__main__":
    main()