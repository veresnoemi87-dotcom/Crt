#!/usr/bin/env bash
# CRT language installer for macOS/Linux.
# Installs crt-cli so the "crt" command works from any terminal.

set -e
cd "$(dirname "$0")"

echo "Checking for Python..."
PYTHON=""
for candidate in python3 python; do
    if command -v "$candidate" >/dev/null 2>&1; then
        PYTHON="$candidate"
        break
    fi
done

if [ -z "$PYTHON" ]; then
    echo "Python 3.8+ was not found on PATH."
    echo "Install it from https://www.python.org/downloads/ (or your"
    echo "system's package manager) and re-run this script."
    exit 1
fi

echo "Using $($PYTHON --version)"
echo "Installing crt-cli..."
"$PYTHON" -m pip install --upgrade pip >/dev/null
if ! "$PYTHON" -m pip install .; then
    echo
    echo "Install failed. See errors above."
    exit 1
fi

echo
read -r -p "Install pygame + Pillow too, for graphics scripts (pygame_init, textures, 3D polygons, etc.)? [Y/n] " GFX
GFX=${GFX:-Y}
case "$GFX" in
    [nN]*) ;;
    *) "$PYTHON" -m pip install pygame Pillow ;;
esac

echo
echo "Done! Try running:  crt"
echo "  crt run yourfile.ct"
echo "  crt build yourfile.ct -o yourfile.cvm"
echo "  crt exec yourfile.cvm"
echo "  crt disasm yourfile.cvm"
echo "  crt run examples_bounce_demo.ct     (needs pygame)"
echo "  crt run examples_3d_demo.ct         (needs pygame + Pillow)"
